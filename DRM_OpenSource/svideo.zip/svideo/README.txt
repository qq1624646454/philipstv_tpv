OpenIPMP GUI demo

- Demonstrates OpenIPMP integration with the Win32 GUI components

Files:
bhornclient.p12 - Local PKCS12 structure that contains user security information and the XML license for both sample media files.

bhornclient-nolicense.p12 - same user security file, but contains no licenses.  You can use this for testing "no local license" scenario.

demo_test_av.mp4 - sample protected video/audio tracks.
demo_test_a.mp4 - sample protected audio.

Installation instructions:

1. Create a directory "localsecurity off the root C: drive (c:\localsecurity).  Copy bhornclient.p12 there.  Currently the IPMP software is hardcoded to look there for.

2. Run the windows player (double-click on "wmp4player.exe").

3. Browse the filesystem for the sample media files.

4. Play either one.  Unless you've logged into the local p12 file, a messagebox should give you some ugly error telling you didn't login in locally:

"P12_LOGIN_MANUAL_FAILED - Unable to locally login..."

If you get this error, select the "File - Login" menu options and you will be presented with a simple login dialog box.

5. Enter "bhornclient" for the username and "objectlab" for the password, this will set the state variables.  Try playing the file(s) again.  Both should play now.  If you keep getting the error, check the case and spelling of the username and password and try again.


Notes:
- The audio file should also be able to be streamed over RTSP:\\ with no problems.  We're having problems with the video.. after a while it hangs up.

- The video clip will probably have a pink border at the bottom during playback.. this is because we had to crop to the original to an even number video height during encoding with XVID.. (it's not any error correction with the decoder)

- Normally, the IPMP software (ContentAuthorizationManager) will contact the OpenIPMP server if it cannot find the license locally.  We don't have the servers finished yet, but if you want to see other ugly error messages, replace bhornclient.p12 with bhornclient-nolicense.p12.

TODO:

- We need to implement the IPMP software as a plug-in.  But we're not sure where to put the IPMPDescriptorPtr ID value (in the ES descriptors or in the IOD...)  This ID will be the ID assigned to openIPMP..  Theoretically, the player should read this value out of the OD stream and instantiate the OPenIPMP dll.  We also need to work out the exported functions that the player will need to implement (Like handling the local authentication Username/Password, and handling the "intent" processing (i.e. the player passes in the intent "PLAY" to the OpenIPMP dll which checks for the license).

- We need to come up with a clean way to handle the streaming and local playback scenarios..  I think the way I'm going to do this is by embedding the IPMPDescriptorPtr in each ES and placing an IPMPUPdate Command at the beginning the OD stream... this is similar to the ISMA spec for the audio and video tracks.. SOMEONE TELL ME IF THIS IS STUPID!!!