package com.fw5.demo.util;

import android.util.Log;

public class LogUtil {
	
	private String TAG ;
	public LogUtil(String tag) {
		// TODO Auto-generated constructor stub
		TAG = tag  ;
	}
	
	public void MaoLog(String text){
		Log.v("Mao",TAG+"-->"+text)  ;
	}
	
	public void MaoLog(char text){
		Log.v("Mao",TAG+"-->"+text)  ;
	}
	
	public void MaoLog(int text){
		Log.v("Mao",TAG+"-->"+text)  ;
	}
	
	public void MaoLog(String[] text){
		for(String s:text){
			Log.v("Mao",TAG+"-->"+s)  ;
		}
	}
}
