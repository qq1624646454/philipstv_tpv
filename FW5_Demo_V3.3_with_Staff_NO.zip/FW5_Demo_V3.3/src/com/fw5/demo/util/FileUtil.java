package com.fw5.demo.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class FileUtil{
	
	private static String TAG = "FileUtil";

	
	private String[] mStrings ;
	private String mString  ;
	private int n = 0  ;
	private LogUtil myLog = new LogUtil(TAG)  ;

	
	public FileUtil(String[] strings){
		mStrings = strings  ;
	}  ;
	
	public FileUtil(String string){
		mString = string  ;
	}  ;
	

	public boolean checkEndsWithInStringArray(String checkItsEnd,
			String[] fileEndings) {
		for (String aEnd : fileEndings) {
			if (checkItsEnd.endsWith(aEnd))
				return true;
		}
		return false;
	}
	
    public void getAllFiles(ArrayList<File> list ,File root){  
    	File files[] = root.listFiles();  
        if(files != null){  
	        for(File f:files){  
	            if(f.isDirectory()){  
	                getAllFiles(list,f);  
	            }else{  
	            	if(checkEndsWithInStringArray(f.getName(), mStrings)){
	            		//myLog.MaoLog("file--->"+f.getName())  ;
	            		list.add(f);  
	            	} 
	            }  
	        }  
        }
    }
    
    
    public void filterFiles(ArrayList<File> source,ArrayList<File> list){
    	myLog.MaoLog("FilterFiles")  ;
    	for(File f:source){
    		if(f.getName().endsWith(mString)){
    			//myLog.MaoLog("getfile--->"+f.getName())  ;
        		list.add(f);  
        	}     		
    	}
    }
    
    public void readText(ArrayList<String> text){
    	File file = new File(mString);
    	BufferedReader br;
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file),"GBK");
			br = new BufferedReader(isr);
			String line = "";
			while((line = br.readLine())!=null){
    			//myLog.MaoLog("getText--->"+line)  ;
				text.add(line);
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }  
}
