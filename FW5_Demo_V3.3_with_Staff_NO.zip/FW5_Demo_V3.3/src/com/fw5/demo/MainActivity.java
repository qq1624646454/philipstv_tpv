package com.fw5.demo;

import com.example.fw5_demo.R;
import com.fw5.demo.MediaList.MediaListForFile;
import com.fw5.demo.mediaplayer.MediaInfo;
import com.fw5.demo.mediaplayer.NormalPlayer;
import com.fw5.demo.util.LogUtil;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements Button.OnClickListener {
	
    private static final String TAG = "MainActivity"  ;

    private Button NormalMediaPlayer,GtvMediaPlayer,GtvPlayerForFlow,
    SmoothStreaming,mButton5,mButton6,mButton7,mButton8;
	private LogUtil myLog = new LogUtil(TAG)  ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initbtn()  ;
	}

	
	private void initbtn() {
		// TODO Auto-generated method stub
		NormalMediaPlayer = (Button) findViewById(R.id.button1)  ;
		NormalMediaPlayer.setOnClickListener(this)  ;	
		GtvMediaPlayer = (Button) findViewById(R.id.button2)  ;
		GtvMediaPlayer.setOnClickListener(this)  ;	
		GtvPlayerForFlow = (Button) findViewById(R.id.button3)  ;
		GtvPlayerForFlow.setOnClickListener(this)  ;	
		SmoothStreaming = (Button) findViewById(R.id.button4)  ;
		SmoothStreaming.setOnClickListener(this)  ;	
		mButton5 = (Button) findViewById(R.id.button5)  ;
		mButton5.setOnClickListener(this)  ;	
		mButton6 = (Button) findViewById(R.id.button6)  ;
		mButton6.setOnClickListener(this)  ;	
		mButton7 = (Button) findViewById(R.id.button7)  ;
		mButton7.setOnClickListener(this)  ;	
		mButton8 = (Button) findViewById(R.id.button8)  ;
		mButton8.setOnClickListener(this)  ;	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public boolean onOptionsItemSelected(MenuItem item){
		myLog.MaoLog("MenuItem -> getItemId -> " + item.getItemId());
		switch(item.getItemId()){
		case R.id.action_info:
			new AlertDialog.Builder(MainActivity.this)
			.setTitle("Application Info")
			.setMessage(R.string.version)
			.setNegativeButton(R.string.back, null).show();
			break;
		}
		return true;
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int id = v.getId()  ;
    	Intent mIntent=new Intent();   
		Bundle bundle = new Bundle();
		myLog.MaoLog("onClick(id " + id + ")");
		switch(id){
        case R.id.button1:  
    		bundle.putInt("Player",MediaInfo.PLAYERTYPE_NORMAL);
    		mIntent.setClass(this, MediaListForFile.class);  
    		mIntent.putExtras(bundle);
            startActivity(mIntent);  
        	break  ;
        case R.id.button2:  
        	bundle.putInt("Player",MediaInfo.PLAYERTYPE_GTV_FOR_FILE); 
    		mIntent.setClass(this, MediaListForFile.class);
    		mIntent.putExtras(bundle);
            startActivity(mIntent);  
        	break  ;
        case R.id.button3:  
        	bundle.putInt("Player",MediaInfo.PLAYERTYPE_GTV_FOR_URL);
    		mIntent.setClass(this, MediaListForFile.class);
    		mIntent.putExtras(bundle);
            startActivity(mIntent);  
        	break  ;
        case R.id.button4:  
          	bundle.putInt("Player",MediaInfo.PLAYERTYPE_SMOOTHSTREAMING);
    		mIntent.setClass(this, MediaListForFile.class);
    		mIntent.putExtras(bundle);
            startActivity(mIntent);  
        	break  ;
        case R.id.button5:  
        	break  ;
        case R.id.button6:  
        	break  ;
        case R.id.button7:  
        	break  ;
        case R.id.button8:  
        	break  ;
		}

	}



}
