package com.fw5.demo.MediaList;

import java.io.File;
import java.util.ArrayList;

import com.example.fw5_demo.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MediaListAdapter extends BaseAdapter {
	
	private static String TAG = "MediaListAdapter";
    private Context context;
    private ArrayList<File> list ;  
	private TextView fileName,filePath;
	private ImageView fileImage  ;
	
	public MediaListAdapter(Context context,ArrayList<File> list){
        this.context = context;
        this.list = list;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
        return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
        return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
        return position;
	}

	
	@Override
    public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflator.inflate(R.layout.media_list_item, null);
        fileName = (TextView)convertView.findViewById(R.id.ItemTitle);
        filePath =(TextView) convertView.findViewById(R.id.ItemText);
        filePath.setVisibility(View.GONE)  ;
        fileImage = (ImageView)convertView.findViewById(R.id.imageView1);
        String name  = list.get(position).getName();  
        fileName.setText(name);
        String path  = list.get(position).getPath();  
        filePath.setText(path);
        return convertView;
	}

}
