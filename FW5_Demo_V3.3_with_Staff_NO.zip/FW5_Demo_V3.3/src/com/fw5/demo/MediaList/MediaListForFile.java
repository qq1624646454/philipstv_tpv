package com.fw5.demo.MediaList;

import java.io.File;
import java.util.ArrayList;

import com.example.fw5_demo.R;
import com.fw5.demo.mediaplayer.GtvPlayerForFlow;
import com.fw5.demo.mediaplayer.MediaInfo;
import com.fw5.demo.mediaplayer.NormalPlayer;
import com.fw5.demo.mediaplayer.SmoothStreamingPlayer;
import com.fw5.demo.util.FileUtil;
import com.fw5.demo.util.LogUtil;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class MediaListForFile extends Activity implements OnItemClickListener {

	private static String TAG = "MediaList";
	
	// view
	private ListView list;
	private FileUtil mUtil;
	private MediaListAdapter mListAdapter;
	private static final int START_SNIFF = 001;
	private static final int FILTER_SNIFF = 002;
	private static final int TEXT_SNIFF = 003;

	private static final int EMPTY_LIST = 101 ; 
	private static final int UPDATE_LIST = 102;
	private static final int UPDATE_LIST_FOR_TEXT = 103;
	
	private Runnable mRun;
	private ListHandler mHandler;
	private Spinner spinner;
	private Button backButton  ;
	private ArrayAdapter<String> SpinnerAdapter,TextAdapter  ;
	private String[] mMainStringList ;
	private String PATH,SelectFile,TextFile;
	private LogUtil myLog = new LogUtil(TAG)  ;
	private Thread mThread  ;
	private boolean inTextFile = false ,isTextList = false;
	private RelativeLayout TopLineView  ;
	private ImageView first;
	private int mPlayerType,top_start ,top_end ;
	private ProgressDialog mProgressDialog  ;
	private TextView emptyText  ;
	// data
	private ArrayList<File> datalist,filterlist;
	private ArrayList<String> textlist;


	/** Called when the activity is first created. */

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.media_list);
		
		/*get info form Intent*/
		Bundle bundle = getIntent().getExtras();
		mPlayerType = bundle.getInt("Player"); 
		
		initView();
		
		//TopAnimation()  ;
	}

	private void TopAnimation() {
		// TODO Auto-generated method stub
		
		myLog.MaoLog("Top Start : "+top_start+"     Top End :"+top_end)  ;
		/* top line test */
		TopLineView = (RelativeLayout)findViewById(R.id.relativeTop)  ;
		first = new ImageView(this);
		first.setTag("first");
		first.setImageResource(R.drawable.topbar_select);
		TopLineView.addView(first)  ;
		top_start = first.getWidth()  ;		
		
		TranslateAnimation animation = new TranslateAnimation(top_start, top_end, 0, 0);
		animation.setDuration(400);
		animation.setFillAfter(true);
		first.bringToFront();
		first.startAnimation(animation);
		animation.setAnimationListener(new AnimationListener(){
			@Override
			public void onAnimationEnd(Animation arg0) {
				// TODO Auto-generated method stub
				arg0.start()  ;
			}

			@Override
			public void onAnimationRepeat(Animation arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onAnimationStart(Animation arg0) {
				// TODO Auto-generated method stub
				
			}})  ;
	}

	/* initialize View*/
	protected void initView() {
		getSDPath() ;
		mHandler = new ListHandler();
		
		/* initialize spinner */
		spinner = (Spinner) findViewById(R.id.spinner1)  ;
		if(isTextList = needFromText()){
			mMainStringList = MediaListForFile.this.getResources().getStringArray(R.array.fileEndingText) ;
		}else{
			mMainStringList = MediaListForFile.this.getResources().getStringArray(R.array.fileEndingVideo) ;
		}
		SpinnerAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,mMainStringList);  
		SpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
        spinner.setOnItemSelectedListener(new SpinnerSelectedListener())  ;
        spinner.setAdapter(SpinnerAdapter);
        SelectFile = spinner.getSelectedItem().toString();
        
		/* initialize backButton */
        backButton = (Button) findViewById(R.id.buttonBack)  ;
        backButton.setOnClickListener(backButtonListener())  ;
        backButton.setVisibility(View.GONE)  ;
        
		/* initialize emptyText */
        emptyText = (TextView) findViewById(R.id.emptyText)  ;
		emptyText.setText(R.string.list_empty)  ;
        emptyText.setVisibility(View.GONE)  ;
        
		/* initialize ArraryLists */
		datalist = new ArrayList<File>();
		filterlist = new ArrayList<File>();
		textlist = new ArrayList<String>()  ;
		
		/* initialize list */
        list = (ListView) findViewById(R.id.music_list);
		list.setOnItemClickListener(MediaListForFile.this);
		
		ThreadOpration(START_SNIFF);
	}

	private boolean needFromText() {
		// TODO Auto-generated method stub
		if(mPlayerType==MediaInfo.PLAYERTYPE_GTV_FOR_URL){
			return true;
		}else if(mPlayerType==MediaInfo.PLAYERTYPE_SMOOTHSTREAMING){
			return true;
		}else{
			return false;
		}
	}

	private OnClickListener backButtonListener() {
		// TODO Auto-generated method stub
		OnClickListener bl = new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mHandler.sendEmptyMessage(UPDATE_LIST)  ;
			}}  ;
		return bl;
	}

	
	/* set path */
	public void getSDPath(){ 
		
        boolean sdCardExist = Environment.getExternalStorageState()   
                              .equals(android.os.Environment.MEDIA_MOUNTED);  
        if  (sdCardExist)   
        {                                  
        	PATH = Environment.getExternalStorageDirectory().getAbsolutePath(); 
        }else{
        	PATH = "" ;
        }           
    } 

	/* ListHandler for update UI */
	class ListHandler extends Handler {
		public ListHandler() {
			super();
		}

		public ListHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case EMPTY_LIST:
				emptyText.setVisibility(View.VISIBLE)  ;
				break;
			case UPDATE_LIST:
				myLog.MaoLog("handleMessage--->UPDATE_LIST");
				emptyText.setVisibility(View.GONE)  ;
				mListAdapter = new MediaListAdapter(MediaListForFile.this, filterlist);
				list.setAdapter(mListAdapter)  ;
				setTextFlag(false)  ;
				break;
			case UPDATE_LIST_FOR_TEXT:
				myLog.MaoLog("handleMessage--->UPDATE_LIST");
				emptyText.setVisibility(View.GONE)  ;
				TextAdapter = new ArrayAdapter<String>(MediaListForFile.this, 
		                android.R.layout.simple_list_item_1,textlist)  ;
				list.setAdapter(TextAdapter)  ;	
				setTextFlag(true)  ;
				break;	
			}
			mProgressDialog.dismiss();
			myLog.MaoLog("mProgressDialog--->CANCEL");	
		}
	}
	
	/* set Text Flag */
	private void setTextFlag(boolean isText) {
		// TODO Auto-generated method stub
		if(inTextFile = isText){
			myLog.MaoLog("text-->true")  ;
			backButton.setVisibility(View.VISIBLE);
			spinner.setVisibility(View.INVISIBLE)  ;
		}else{ 
			myLog.MaoLog("text-->false")  ;
			backButton.setVisibility(View.GONE)  ;
			spinner.setVisibility(View.VISIBLE)  ;
		}  
	}
	
	
	public void OpenFile(final File file){
		String path = null ;
		//if(file.getName().endsWith(".txt") && isTextFile==false){
		if(isTextList==true){
			TextFile = file.getAbsolutePath()  ;
			ThreadOpration(TEXT_SNIFF);
			return  ;
		}
		if(file!=null){
			path = file.getAbsolutePath();
		}
		OpenFile(path)  ;
	}
	
	public void OpenFile(final String path) {
		
		new AlertDialog.Builder(MediaListForFile.this)
				.setTitle(R.string.openfile_title)
				.setMessage(path)
				.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						/* Toast.makeText(MediaList.this, getString(R.string.choosed) + path,
								Toast.LENGTH_SHORT).show(); */
						Intent mIntent = new Intent()  ;
						Bundle bundle = new Bundle();
						bundle.putString("path", path);
						bundle.putString("usbdisk",PATH) ;
						switch(mPlayerType){
							case MediaInfo.PLAYERTYPE_NORMAL:
							myLog.MaoLog("Intent --> NormalPlayer")  ;
								mIntent.setClass(MediaListForFile.this,NormalPlayer.class);
							break  ;
							case MediaInfo.PLAYERTYPE_GTV_FOR_URL:
							case MediaInfo.PLAYERTYPE_GTV_FOR_FILE:
							myLog.MaoLog("Intent --> GTVmediaPlayer for flow")  ;
								mIntent.setClass(MediaListForFile.this,GtvPlayerForFlow.class);
							break  ;	
							case MediaInfo.PLAYERTYPE_SMOOTHSTREAMING:
							myLog.MaoLog("Intent --> smoothstreaming play")  ;
								mIntent.setClass(MediaListForFile.this,SmoothStreamingPlayer.class);
							break  ;
						}
							
						mIntent.putExtras(bundle);
						MediaListForFile.this.startActivity(mIntent);
					}
				}).show();
	}


	@Override
	public void onItemClick(AdapterView<?> list, View view, int i, long arg3) {
		// TODO Auto-generated method stub
		myLog.MaoLog("onItemClick---->"+i)  ;

		if(inTextFile){
			myLog.MaoLog("open text")  ;
			OpenFile(textlist.get(i));
		}else{
			myLog.MaoLog("oopen file")  ;
			OpenFile(filterlist.get(i));
		}
	}
	
	public void ThreadOpration(int s) {
		myLog.MaoLog("handleMessage--->ThreadOpration : "+s);	
		

		myLog.MaoLog("mProgressDialog--->BEGIN");	
		switch (s) {
		case START_SNIFF:
			myLog.MaoLog("ThreadOpration---->START_SNIFF")  ;
			mRun = new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					if(!PATH.equals("")){
						mUtil = new FileUtil(mMainStringList);					
						mUtil.getAllFiles(datalist, new File(PATH));
					}
				}
			};
			break;
			
			
		case FILTER_SNIFF:
			mProgressDialog = ProgressDialog.show(MediaListForFile.this, null, "Loading...");  
			myLog.MaoLog("ThreadOpration---->FILTER_SNIFF")  ;
			mRun = new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					filterlist.clear();
					mUtil = new FileUtil(SelectFile);					
					mUtil.filterFiles(datalist,filterlist);
					mHandler.sendEmptyMessage(UPDATE_LIST)  ;
					if(filterlist.isEmpty()){
						mHandler.sendEmptyMessage(EMPTY_LIST)  ;
					}
				}
			};
			break  ;
			
		case TEXT_SNIFF:
			mProgressDialog = ProgressDialog.show(MediaListForFile.this, null, "Loading...");  
			myLog.MaoLog("ThreadOpration---->TEXT_SNIFF")  ;
			mRun = new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					textlist.clear();
					mUtil = new FileUtil(TextFile);					
					mUtil.readText(textlist);
					mHandler.sendEmptyMessage(UPDATE_LIST_FOR_TEXT)  ;
					if(textlist.isEmpty()){
						mHandler.sendEmptyMessage(EMPTY_LIST)  ;
					}
				}
			};
			break  ;
		}
		if (mRun != null) {
			mThread = new Thread(mRun)  ;
			myLog.MaoLog("mThread---->"+mThread.getId()+"");
			mThread.start();
		}
	}
	

	
	class SpinnerSelectedListener implements OnItemSelectedListener{

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
	        SelectFile = spinner.getSelectedItem().toString();
	        
			ThreadOpration(FILTER_SNIFF);
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
		
		
		
	
	
	
}
