package com.fw5.demo.MediaList;


import com.example.fw5_demo.R;
import com.google.android.tv.media.GtvMediaPlayer.TrackInfo;

import android.content.Context;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MediaTrackAdapter extends BaseAdapter {
	private TrackInfo[] list  ;
    private Context context;
	private TextView TrackType,TrackIndex,TrackLanguage;
	
	public MediaTrackAdapter(Context c ,TrackInfo[] trackInfos) {
		// TODO Auto-generated constructor stub
		this.context = c  ;
		this.list = trackInfos  ;
		Log.v("Mao","MediaTrackAdapter")  ;
		Log.v("Mao","list="+list.length)  ;

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		Log.v("Mao","getView position"+position)  ;
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflator.inflate(R.layout.track_list_item, null);
        TrackType = (TextView)convertView.findViewById(R.id.trackType);
        TrackIndex =(TextView) convertView.findViewById(R.id.trackIndex);
        TrackLanguage =(TextView) convertView.findViewById(R.id.trackLanguage);
        TrackType.setText(CheckType(list[position]))  ;
        TrackIndex.setText("Index:"+position);
        TrackLanguage.setText("Language:"+list[position].getLanguage())  ;
        return convertView  ;
	}

	public String CheckType(TrackInfo info){
		String type = null  ;
		if(info.getTrackType() == TrackInfo.MEDIA_TRACK_TYPE_TIMEDTEXT){
			type = "TimedTextTrack"  ;
		}else if(info.getTrackType() == TrackInfo.MEDIA_TRACK_TYPE_AUDIO){
			type = "AudioTrack"  ;
		}else if(info.getTrackType() == TrackInfo.MEDIA_TRACK_TYPE_VIDEO){
			type = "VedioTrack"  ;
		}else{
			type = "UnknownTrack"  ;
		}
		return type;
	}
}
