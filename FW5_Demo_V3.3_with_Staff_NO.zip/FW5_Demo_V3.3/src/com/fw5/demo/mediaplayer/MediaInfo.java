package com.fw5.demo.mediaplayer;

public class MediaInfo {
	
	public static final int STATE_IDLE = 1100;
	public static final int STATE_INITIALIZED = 1101;
	public static final int STATE_PREPARED = 1102;
	public static final int STATE_PREPARING = 1103;
	public static final int STATE_STARTED = 1104;
	public static final int STATE_PAUSED = 1105;
	public static final int STATE_STOPPED = 1106;
	public static final int STATE_PLAYBACKCOMPLETED = 1107;
	public static final int STATE_ERROR = 1108;
	public static final int STATE_END = 1109;
	public static final int STATE_NEW = 0000;


	
	public static final int DO_SETDATASOURCE = 1000;
	public static final int DO_PREPAREASYNC = 1001;
	public static final int DO_START = 1002;
	public static final int DO_PAUSE = 1003;
	public static final int DO_STOP = 1004;
	public static final int DO_NEW = 1005;
	public static final int DO_RELEASE = 1006;
	public static final int DO_RESET = 1007;
	public static final int DO_PREPARE = 1008;
	public static final int DO_SUBTITLE =1009;
	public static final int DO_SEEK = 1010;
	public static final int DO_SELECTAUDIO =1011;
	public static final int DO_AUTOPLAY = 1012;
	
	public static final int PLAYERTYPE_NORMAL = 2001;
	public static final int PLAYERTYPE_GTV_FOR_FILE = 2002;
	public static final int PLAYERTYPE_GTV_FOR_URL = 2003;
	public static final int PLAYERTYPE_SMOOTHSTREAMING = 2004;

	
}
