package com.fw5.demo.mediaplayer;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import com.example.fw5_demo.R;
import com.fw5.demo.MediaList.MediaListAdapter;
import com.fw5.demo.MediaList.MediaListForFile;
import com.fw5.demo.MediaList.MediaTrackAdapter;
import com.fw5.demo.util.FileUtil;
import com.fw5.demo.util.LogUtil;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.TrackInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.google.android.tv.media.*;
import com.google.android.tv.media.GtvMediaPlayer.OnTimedTextListener;

public class GtvPlayerForFlow extends Activity implements Callback,
		OnPreparedListener, OnCompletionListener, OnClickListener,
		OnErrorListener, OnTimedTextListener {

	private static String TAG = "GtvPlayer For Flow";
	private int mState = MediaInfo.STATE_NEW;
	private SurfaceView surfaceView = null;
	private SurfaceHolder surfaceholder = null;
	private GtvMediaPlayer mMediaplayer = null;
	private OperateHandler mOperateHandler;
	private Button mSetDataSource, mPrepareAsync, mStart, mPause, mStop,
			mRelease, mReset, mPrepare, mNew, mSubTitle,mAutoPlay,mSeek,mSelectAudio;
	private ImageView mStateView;
	private TextView mTextView,mPathView,mDuration,mPosition,txtDisplay;
	private FileUtil mUtil;
	private ArrayList<File> datalist;
	private MediaListAdapter mListAdapter;
	private ProgressDialog mProgressDialog ;
	ListView mListview  ;
	private String PATH,path_string,path_subtitle="";
	private LogUtil myLog = new LogUtil(TAG);
	private boolean hasSubTitle = false ;
	private boolean isAutoPlay = false ;
	private Handler timeHandler  ;
	private DelayThread delaythread  ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Bundle bundle = getIntent().getExtras();
		PATH = bundle.getString("path");
		path_string = bundle.getString("usbdisk")  ;
		setContentView(R.layout.flow_mediaplayer);
		mOperateHandler = new OperateHandler();
		initView();
		timeHandler = new Handler(){
            public void handleMessage(Message msg){
            	if(mMediaplayer!=null){
            		mDuration.setText(mMediaplayer.getDuration()+"") ;
            		mPosition.setText(mMediaplayer.getCurrentPosition()+"");        
            	}
        	}
    };//ʵ����Ϣ����
	}

	
	private void initView() {
		// TODO Auto-generated method stub
		surfaceView = (SurfaceView)findViewById(R.id.SurfaceViewForFlow);
		surfaceholder = surfaceView.getHolder();
		surfaceView.setLayoutParams(new RelativeLayout.LayoutParams(720, 405));
		surfaceholder.addCallback(this);
		mAutoPlay = (Button)findViewById(R.id.auto_play_btn);
		mAutoPlay.setOnClickListener(this);
		mSeek = (Button)findViewById(R.id.seek_btn);
		mSeek.setOnClickListener(this);
		mSelectAudio = (Button)findViewById(R.id.selectaudio_btn);
		mSelectAudio.setOnClickListener(this);
		mSetDataSource = (Button)findViewById(R.id.setDataSource_btn);
		mSetDataSource.setOnClickListener(this);
		mPrepareAsync = (Button)findViewById(R.id.prepareAsync_btn);
		mPrepareAsync.setOnClickListener(this);
		mStart = (Button)findViewById(R.id.start_btn);
		mStart.setOnClickListener(this);
		mPause = (Button)findViewById(R.id.pause_btn);
		mPause.setOnClickListener(this);
		mStop = (Button)findViewById(R.id.stop_btn);
		mStop.setOnClickListener(this);
		mRelease = (Button)findViewById(R.id.release_btn);
		mRelease.setOnClickListener(this);
		mReset = (Button)findViewById(R.id.reset_btn);
		mReset.setOnClickListener(this);
		mPrepare = (Button)findViewById(R.id.prepare_btn);
		mPrepare.setOnClickListener(this);
		mNew = (Button)findViewById(R.id.new_btn);
		mNew.setOnClickListener(this);
		mPathView = (TextView)findViewById(R.id.path);
		mPathView.setText(PATH);
		mTextView = (TextView)findViewById(R.id.textpath)  ;
		txtDisplay = (TextView)findViewById(R.id.timedtextView);
		mDuration = (TextView)findViewById(R.id.duration)  ;
		mPosition = (TextView)findViewById(R.id.position);
		mStateView = (ImageView) findViewById(R.id.state_view);
		mSubTitle = (Button) findViewById(R.id.subtitle_btn);
		mSubTitle.setOnClickListener(this);
		updateView(mState);
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		myLog.MaoLog("surfaceCreated");
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		myLog.MaoLog("surfaceChanged");

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		myLog.MaoLog("surfaceDestroyed");
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		// TODO Auto-generated method stub

		myLog.MaoLog("onPrepared(MediaPlayer mp)");
		mState = MediaInfo.STATE_PREPARED;
		if(hasSubTitle){
			SetTimedText(path_subtitle)  ;
		}
		updateView(mState);
		
		if(isAutoPlay){
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_START);
			isAutoPlay = false   ;
		}
		myLog.MaoLog(mState);
	}

	private void SetTimedText(String txtpath) {
		// TODO Auto-generated method stub
		try {			
			mMediaplayer.addTimedTextSource(txtpath,
					GtvMediaPlayer.MEDIA_MIMETYPE_TEXT_SUBRIP);
			
			myLog.MaoLog("mp.addTimedTextSource ")  ;

		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private int findTrackIndexFor(int mediaTrackType, TrackInfo[] trackInfo) {
	    int index = -1 , n = 0;
	    for (int i = 0; i < trackInfo.length; i++) {
	    	myLog.MaoLog("i="+i+"   Language-->"+trackInfo[i].getLanguage())  ;
	        if (trackInfo[i].getTrackType() == mediaTrackType) {
	            return i;
	        }
	    }
	    return index;
	}
	
	
	public void findTrackIndexFor(ArrayList<Integer> track,
			int mediaTrackType,TrackInfo[] trackInfo) {
		// TODO Auto-generated method stub
	    for (int i = 0; i < trackInfo.length; i++) {
	    	myLog.MaoLog("i="+i+"   Language-->"+trackInfo[i].getLanguage())  ;
	        if (trackInfo[i].getTrackType() == mediaTrackType) {
	        	track.add(i)  ;
	        }
	    }
	}
	
	@Override
	public void onCompletion(MediaPlayer mp) {
		// TODO Auto-generated method stub
		mState = MediaInfo.STATE_PLAYBACKCOMPLETED;
		updateView(mState);
		myLog.MaoLog(mState);
	}

	private void updateView(int state) {
		// TODO Auto-generated method stub
		switch (state) {
		case MediaInfo.STATE_IDLE:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(true);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_idle);
			break;
		case MediaInfo.STATE_INITIALIZED:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(true);
			mPrepare.setEnabled(true);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_initialized);
			break;
		case MediaInfo.STATE_PAUSED:
			mStart.setEnabled(true);
			mPause.setEnabled(false);
			mStop.setEnabled(true);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(true)  ;
			mStateView.setImageResource(R.drawable.state_paused);
			break;
		case MediaInfo.STATE_PREPARED:
			mStart.setEnabled(true);
			mPause.setEnabled(false);
			mStop.setEnabled(true);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(true)  ;
			mStateView.setImageResource(R.drawable.state_prepared);
			break;
		case MediaInfo.STATE_STARTED:
			mStart.setEnabled(false);
			mPause.setEnabled(true);
			mStop.setEnabled(true);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(true)  ;
			mStateView.setImageResource(R.drawable.state_started);
			break;
		case MediaInfo.STATE_STOPPED:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(true);
			mPrepare.setEnabled(true);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_stoped);
			break;
		case MediaInfo.STATE_END:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(true);
			mReset.setEnabled(false);
			mRelease.setEnabled(false);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_end);
			break;
		case MediaInfo.STATE_PLAYBACKCOMPLETED:
			mStart.setEnabled(true);
			mPause.setEnabled(false);
			mStop.setEnabled(true);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(true)  ;
			mStateView.setImageResource(R.drawable.state_playbackcompleted);
			break;
		case MediaInfo.STATE_ERROR:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_error);
			break;
		case MediaInfo.STATE_PREPARING:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(false);
			mReset.setEnabled(true);
			mRelease.setEnabled(true);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_preparing);
			break;
		case MediaInfo.STATE_NEW:
			mStart.setEnabled(false);
			mPause.setEnabled(false);
			mStop.setEnabled(false);
			mSetDataSource.setEnabled(false);
			mPrepareAsync.setEnabled(false);
			mPrepare.setEnabled(false);
			mNew.setEnabled(true);
			mReset.setEnabled(false);
			mRelease.setEnabled(false);
			mSeek.setEnabled(false)  ;
			mStateView.setImageResource(R.drawable.state_new);
			break;
		}

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if (mMediaplayer != null) {
			mMediaplayer.release();
			mMediaplayer = null;
		}
		super.onDestroy();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.setDataSource_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_SETDATASOURCE);
			break;
		case R.id.prepareAsync_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_PREPAREASYNC);
			break;
		case R.id.start_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_START);
			break;
		case R.id.pause_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_PAUSE);
			break;
		case R.id.stop_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_STOP);
			break;
		case R.id.release_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_RELEASE);
			break;
		case R.id.reset_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_RESET);
			break;
		case R.id.new_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_NEW);
			break;
		case R.id.prepare_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_PREPARE);
			break;
		case R.id.subtitle_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_SUBTITLE)  ;
			break  ;
		case R.id.seek_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_SEEK)  ;
			break  ;
		case R.id.auto_play_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_AUTOPLAY)  ;
			break  ;
		case R.id.selectaudio_btn:
			mOperateHandler.sendEmptyMessage(MediaInfo.DO_SELECTAUDIO)  ;
			break  ;
		
		}
	}

	class OperateHandler extends Handler {
		
		public OperateHandler() {
			super();
		}

		public OperateHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MediaInfo.DO_SETDATASOURCE:
				myLog.MaoLog("handleMessage--->SETDATASOURCE");
				doSetDataSource();
				break;
			case MediaInfo.DO_PREPAREASYNC:
				myLog.MaoLog("handleMessage--->PREPAREASYNC");
				doPrepareAsync();
				break;
			case MediaInfo.DO_START:
				myLog.MaoLog("handleMessage--->START");
				doStart();
				break;
			case MediaInfo.DO_PAUSE:
				myLog.MaoLog("handleMessage--->PAUSE");
				doPause();
				break;
			case MediaInfo.DO_NEW:
				myLog.MaoLog("handleMessage--->NEW");
				doNew();
				break;
			case MediaInfo.DO_PREPARE:
				myLog.MaoLog("handleMessage--->PREPARE");
				doPrepare();
				break;
			case MediaInfo.DO_RESET:
				myLog.MaoLog("handleMessage--->RESET");
				doReset();
				break;
			case MediaInfo.DO_RELEASE:
				myLog.MaoLog("handleMessage--->RELEASE");
				doRelease();
				break;
			case MediaInfo.DO_STOP:
				myLog.MaoLog("handleMessage--->STOP");
				doStop();
				break;
			case MediaInfo.DO_SUBTITLE:
				myLog.MaoLog("handleMessage---->SUBTITLE")  ;
				doSubTitle()  ;
				break  ;
			case MediaInfo.DO_SEEK:
				myLog.MaoLog("handleMessage--->SEEK");
				doSeek();
				break;
			case MediaInfo.DO_SELECTAUDIO:
				myLog.MaoLog("handleMessage--->SELECTAUDIO");
				doSelectAudio();
				break;
			case MediaInfo.DO_AUTOPLAY:
				myLog.MaoLog("handleMessage---->AUTOPLAY")  ;
				doAutoPlay()  ;
				break  ;
			}
			updateView(mState);
			myLog.MaoLog(mState);
		}

		private boolean initMediaPlayer() {
			// TODO Auto-generated method stub
			if (mMediaplayer == null) {
				mMediaplayer = new GtvMediaPlayer();
				mMediaplayer.setDisplay(surfaceholder);
				mMediaplayer.setOnPreparedListener(GtvPlayerForFlow.this);
				mMediaplayer.setOnCompletionListener(GtvPlayerForFlow.this);
				mMediaplayer.setOnErrorListener(GtvPlayerForFlow.this);
				mMediaplayer.setOnTimedTextListener(GtvPlayerForFlow.this)  ;
				myLog.MaoLog("mediaplayer = new MediaPlayer(); ");
				return true;
			}
			return false;
		}
		
		
		private void doAutoPlay() {
			// TODO Auto-generated method stub
			isAutoPlay = true  ;
			doRelease()  ;
			doNew()  ;
			doSetDataSource()  ;
			doPrepare()  ;
		}

		private void doSelectAudio() {
			// TODO Auto-generated method stub
			ListView mListview = new ListView(GtvPlayerForFlow.this);
				MediaTrackAdapter mMediaPlayer = new MediaTrackAdapter(GtvPlayerForFlow.this ,mMediaplayer.getTrackInfo())  ;
				mListview.setAdapter(mMediaPlayer);
	            final AlertDialog mAlertDialog = new AlertDialog.Builder(GtvPlayerForFlow.this)
	                        .setTitle("Select Subtitle")
	                        .setIcon(android.R.drawable.ic_dialog_info)
	                        .setView(mListview)
	                        .create();
	            mAlertDialog.show()  ;
	            
	            mListview.setOnItemClickListener(new OnItemClickListener(){
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int i, long arg3) {
						// TODO Auto-generated method stub
						if(mMediaplayer!=null){
							myLog.MaoLog("selectTrack="+i)  ;
							mMediaplayer.selectTrack(i);
						}
						mAlertDialog.dismiss()  ;
					}
				})  ;
		}

		private void doSeek() {
			// TODO Auto-generated method stub
			final EditText mEditText = new EditText(GtvPlayerForFlow.this)  ;
			new AlertDialog.Builder(GtvPlayerForFlow.this).setTitle("Seek to :")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setView(mEditText)
							.setPositiveButton("ȷ��", new android.content.DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface arg0,
										int arg1) {
									// TODO Auto-generated method stub
									int data = 0  ;
									String str =  mEditText.getText().toString();
					                   if (str != null && str.length() > 0) {
					                        data = Integer.parseInt(str);
					                    }
					                    if (mMediaplayer != null) {
					                    	myLog.MaoLog("doSeek() -- >"+data)  ;
  											mMediaplayer.seekTo(data)  ;
					                    }
								}})
							.setNegativeButton("ȡ��", null).show();
			
		}

		private void doSubTitle() {
			// TODO Auto-generated method stub
				
			ListView mListview = new ListView(GtvPlayerForFlow.this);
				datalist = new ArrayList<File>();
				mUtil = new FileUtil(GtvPlayerForFlow.this.getResources().getStringArray(R.array.fileEndingSubtitle));
				mUtil.getAllFiles(datalist, new File(path_string));
				mListAdapter = new MediaListAdapter(GtvPlayerForFlow.this, datalist);
	            mListview.setAdapter(mListAdapter);
	            final AlertDialog mAlertDialog = new AlertDialog.Builder(GtvPlayerForFlow.this)
	                        .setTitle("Select Subtitle")
	                        .setIcon(android.R.drawable.ic_dialog_info)
	                        .setView(mListview)
	                        .create();
				mProgressDialog.cancel()  ;
	            mAlertDialog.show()  ;
	            mListview.setOnItemClickListener(new OnItemClickListener(){
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int i, long arg3) {
						// TODO Auto-generated method stub
						path_subtitle = datalist.get(i).getAbsolutePath()  ;
						mTextView.setText(path_subtitle)  ;
						myLog.MaoLog("path_subtitle >"+path_subtitle)  ;
						hasSubTitle = true  ;
						}})  ;
						
		}

		private void doSetDataSource() {
			// TODO Auto-generated method stub
			if (mState != MediaInfo.STATE_IDLE) {
				return;
			}
			try {
				mMediaplayer.setDataSource(PATH);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mState = MediaInfo.STATE_INITIALIZED;
		}

		private int doStop() {
			// TODO Auto-generated method stub
			if (mState == MediaInfo.STATE_PREPARED
					|| mState == MediaInfo.STATE_STARTED
					|| mState == MediaInfo.STATE_PAUSED) {
				mMediaplayer.stop();
				mState = MediaInfo.STATE_STOPPED;
			}
			return mState;
		}

		private int doNew() {
			if (initMediaPlayer()) {
				mState = MediaInfo.STATE_IDLE;
			}
			return mState;
		}

		private int doReset() {
			mMediaplayer.reset();
			mState = MediaInfo.STATE_IDLE;
			return mState;
		}

		private int doRelease() {
			if(mMediaplayer != null ){
				mMediaplayer.release();
			}
			mMediaplayer = null  ;
			mState = MediaInfo.STATE_END;
			isAutoPlay = false  ;
			if(delaythread!=null){
				delaythread.stop()  ;
				delaythread = null  ;
			}
			return mState;
		}

		private int doPrepare() {
			if (mState == MediaInfo.STATE_INITIALIZED
					|| mState == MediaInfo.STATE_STOPPED) {
				try {
					mMediaplayer.prepare();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mState = MediaInfo.STATE_PREPARING;
			}
			if(delaythread!=null){
				delaythread=new DelayThread(100);
			}
	        delaythread.start();
			return mState;
		}

		private int doPause() {
			// TODO Auto-generated method stub
			if (mState == MediaInfo.STATE_STARTED) {
				mMediaplayer.pause();
				mState = MediaInfo.STATE_PAUSED;
			}
			return mState;
		}

		private int doStart() {
			// TODO Auto-generated method stub
			if (mState == MediaInfo.STATE_PREPARED
					|| mState == MediaInfo.STATE_PAUSED
					|| mState == MediaInfo.STATE_PLAYBACKCOMPLETED) {
				
				mMediaplayer.start();
		            DelayThread delaythread=new DelayThread(1000);
		            delaythread.start();
				mState = MediaInfo.STATE_STARTED;
			}
			return mState;
		}

		
		private int doPrepareAsync() {
			// TODO Auto-generated method stub
			if (mState == MediaInfo.STATE_INITIALIZED
					|| mState == MediaInfo.STATE_STOPPED) {
				mMediaplayer.prepareAsync();
				mState = MediaInfo.STATE_PREPARING;
			}
			
			return mState;
		}
	}

	@Override
	public boolean onError(MediaPlayer arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub
		mState = MediaInfo.STATE_ERROR;
		updateView(mState);
		myLog.MaoLog(mState);
		return true;
	}



	@Override
	public void onTimedText(GtvMediaPlayer mp,GtvTimedText text) {
		// TODO Auto-generated method stub
		myLog.MaoLog("onTimedText!! Text="+text);
	}
	
    class DelayThread extends Thread{
        int milliseconds;
        public DelayThread(int i){
            milliseconds=i;
        }
        public void run(){
            while(true){
                try {
                    sleep(milliseconds);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                if(timeHandler!=null){
                	timeHandler.sendEmptyMessage(0);
                }
            }
        }
        
    }
	
	public String secondsToDuration(int seconds) {
	    return String.format("%02d:%02d:%02d", seconds / 3600,
	            (seconds % 3600) / 60, (seconds % 60), Locale.US);
	}


	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if(mMediaplayer != null ){
			mMediaplayer.release();
		}
		mMediaplayer = null  ;
		if(delaythread!=null){
			delaythread.stop()  ;
			delaythread = null  ;
		}
		
		myLog.MaoLog("onBackPressed()")  ;
		super.onBackPressed();
	}
	
	

}
