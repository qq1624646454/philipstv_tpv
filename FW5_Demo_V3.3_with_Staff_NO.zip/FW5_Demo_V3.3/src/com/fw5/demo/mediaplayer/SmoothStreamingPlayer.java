package com.fw5.demo.mediaplayer;

import java.io.IOException;

import com.example.fw5_demo.R;
import com.framework.tv.smoothstreaming.SmoothStreamingSource;
import com.google.android.tv.media.*;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.MediaController.MediaPlayerControl;
import android.widget.Toast;

public class SmoothStreamingPlayer extends Activity implements SurfaceHolder.Callback, 
OnCompletionListener, OnPreparedListener, OnClickListener, MediaPlayerControl{
	
	private SurfaceView surfaceView = null;
	private SurfaceHolder surfaceholder = null;
	private GtvMediaPlayer mediaplayer = null;
	private MediaSource mediaSource = null;
	private MediaController mediacontroller = null;
    private TextView txtDisplay  ;
	private Button mSubTitle  ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		Log.v("LXM_PRINT_LOG: ", "start MediaActivity");
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		Bundle path_bundle = getIntent().getExtras();
		
		String path_string= path_bundle.getString("path");
		
		setContentView(R.layout.normal_mediaplayer);
		surfaceView = (SurfaceView)findViewById(R.id.SurfaceView);
		surfaceholder = surfaceView.getHolder();
		//surfaceholder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		surfaceholder.addCallback(this);
		
		Log.v("LXM_PRINT_LOG: ", path_string);
		
		mediaplayer = new GtvMediaPlayer();
		Log.v("LXM_PRINT_LOG","mediaplayer = new GtvMediaPlayer() OK! ")  ;
		
		mediaSource = new SmoothStreamingSource(path_string, SmoothStreamingPlayer.this);
		try{
			Log.v("LXM_PRINT_LOG: ", "setDataSource");
			mediaplayer.setDataSource(mediaSource);
		}catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		}
		mediacontroller = new MediaController(this);
		
		mediaplayer.setOnPreparedListener(this);
		mediaplayer.setOnCompletionListener(this);
		
		mSubTitle = (Button)findViewById(R.id.subtitle_btn)  ;
		mSubTitle.setVisibility(View.GONE)  ;
		
		txtDisplay = (TextView)findViewById(R.id.timedtextView)  ;
		txtDisplay.setText(path_string) ;
		
	}


	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		mediaplayer.setDisplay(surfaceholder);
		try {
			Log.v("LXM_PRINT_LOG: ", "surfaceCreated  prepare");
			mediaplayer.prepare();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		if(mediacontroller.isShowing())
		{
			mediacontroller.hide();
		}
		else
		{
			mediacontroller.show();
		}
		return false;
	}
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean canPause() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean canSeekBackward() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean canSeekForward() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getBufferPercentage() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCurrentPosition() {
		// TODO Auto-generated method stub
		return mediaplayer.getCurrentPosition();
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return mediaplayer.getDuration();
	}

	@Override
	public boolean isPlaying() {
		// TODO Auto-generated method stub
		return mediaplayer.isPlaying();
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		mediaplayer.pause();
	}

	@Override
	public void seekTo(int pos) {
		// TODO Auto-generated method stub
		mediaplayer.seekTo(pos);
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		Log.v("LXM_PRINT_LOG: ", "start.......");
		mediaplayer.start();
	}

	@Override
	public int getAudioSessionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	

	@Override
	public void onPrepared(MediaPlayer mp) {
		// TODO Auto-generated method stub
		Log.v("LXM_PRINT_LOG: ", "start mediaplayer !");
		mp.start();
		mediacontroller.setMediaPlayer(this);
		mediacontroller.setAnchorView(this.findViewById(R.id.SurfaceView));
		mediacontroller.setEnabled(true);
		mediacontroller.show();
	}

	@Override
	public void onCompletion(MediaPlayer arg0) {
		// TODO Auto-generated method stub
		finish();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(mediaplayer != null)
		{
			mediaplayer.release();
			mediaplayer = null;
		}
		super.onDestroy();
	}
	
}
