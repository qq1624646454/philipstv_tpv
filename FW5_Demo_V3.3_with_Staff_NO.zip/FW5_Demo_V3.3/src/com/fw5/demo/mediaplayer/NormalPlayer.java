package com.fw5.demo.mediaplayer;

import java.io.IOException;

import com.example.fw5_demo.R;
import com.fw5.demo.util.LogUtil;
import com.google.android.tv.media.GtvMediaPlayer;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class NormalPlayer extends Activity implements Callback, 
				OnPreparedListener, OnCompletionListener,OnClickListener{

	private static String TAG = "NormalPlayer";
	
	
	private SurfaceView surfaceView = null;
	private SurfaceHolder surfaceholder = null;
	private GtvMediaPlayer mediaplayer = null;
    private TextView txtDisplay  ;
	private Button mSubTitle  ;
	private LogUtil myLog = new LogUtil(TAG)  ;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Bundle bundle = getIntent().getExtras();
		String path_string= bundle.getString("path");
		
		setContentView(R.layout.normal_mediaplayer);
		surfaceView = (SurfaceView)findViewById(R.id.SurfaceView);
		surfaceholder = surfaceView.getHolder();
		//surfaceholder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		surfaceholder.addCallback(this);

		mediaplayer = new GtvMediaPlayer();

		
		myLog.MaoLog("mediaplayer = new MediaPlayer(); ")  ;
		
		try {
			mediaplayer.setDataSource(path_string);
			myLog.MaoLog("mediaplayer.setDataSource(path_string);")  ;

		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			finish();
			e.printStackTrace();
		}
		
		mediaplayer.setOnPreparedListener(this);
		mediaplayer.setOnCompletionListener(this);

		
		mSubTitle = (Button)findViewById(R.id.subtitle_btn)  ;
		mSubTitle.setVisibility(View.GONE)  ;
		
		txtDisplay = (TextView)findViewById(R.id.timedtextView)  ;
		txtDisplay.setVisibility(View.GONE)  ;
	}
	
	
	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
		myLog.MaoLog("surfaceCreated") ;
		mediaplayer.setDisplay(surfaceholder);
		myLog.MaoLog("mediaplayer.setDisplay") ;


		try {
			mediaplayer.prepare();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myLog.MaoLog("mediaplayer.prepare()") ;

		
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}

	
	@Override
	public void onPrepared(MediaPlayer mp) {
		// TODO Auto-generated method stub
		
		myLog.MaoLog("onPrepared(MediaPlayer mp)");
		//SetTimedText()  ;
		mp.start();
		myLog.MaoLog("mediaplayer.prepare()");
		
	}
	
	
	@Override
	public void onCompletion(MediaPlayer mp) {
		// TODO Auto-generated method stub
		finish();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(mediaplayer != null)
		{
			mediaplayer.release();
			mediaplayer = null;
		}
		super.onDestroy();
	}


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		
		}
	}

}
