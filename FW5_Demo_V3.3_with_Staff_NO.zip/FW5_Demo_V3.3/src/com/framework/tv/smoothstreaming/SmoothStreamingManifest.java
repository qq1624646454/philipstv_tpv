/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import com.framework.tv.smoothstreaming.SmoothStreamingConstants.StreamType;

import java.util.ArrayList;
import java.util.List;

public class SmoothStreamingManifest {
    public static interface ElementBase {
        void addElement(ElementBase child);
    }

    public static class ProtectionHeaderElement implements ElementBase {
        private String mSystemId;
        private String mHeaderContent;

        ProtectionHeaderElement() {
            mSystemId = null;
            mHeaderContent = null;
        }

        @Override
        public void addElement(ElementBase child) {
            // should not be called.
            assert(false);
        }

        public String getSystemId() {
            return mSystemId;
        }

        public void setSystemId(String systemId) {
            this.mSystemId = systemId;
        }

        public String getHeaderContent() {
            return mHeaderContent;
        }

        public void setHeaderContent(String headerContent) {
            this.mHeaderContent = headerContent;
        }
    }

    public static class ProtectionElement implements ElementBase {
        private ProtectionHeaderElement mProtectionHeader;

        public ProtectionHeaderElement getProtectionHeader() {
            return mProtectionHeader;
        }

        @Override
        public void addElement(ElementBase child) {
            assert(child instanceof ProtectionHeaderElement);
            assert(mProtectionHeader == null);
            mProtectionHeader = (ProtectionHeaderElement) child;
        }
    }

    public static class TrackElement implements ElementBase {
        // Required for all.
        private int mIndex;
        private int mBitrate;

        // Audio-video
        private String mCodecPrivateData;

        // Video-only
        private int mMaxWidth;
        private int mMaxHeight;

        // Audio-only
        private int mSamplingRate;
        private int mChannels;
        private int mPacketSize;
        private int mAudioTag;
        private int mBitPerSample;
        private String mFourCC;

        private int mNalUnitLengthField;
        private String mContent;

        TrackElement() {
            mIndex = -1;
            mBitrate = -1;

            // Audio-video
            mCodecPrivateData = null;

            // Video-only
            mMaxWidth = -1;
            mMaxHeight = -1;

            // Audio-only
            mSamplingRate = -1;
            mChannels = -1;
            mPacketSize = -1;
            mAudioTag = -1;
            mBitPerSample = -1;
            mFourCC = null;

            mNalUnitLengthField = SmoothStreamingConstants.DEFAULT_NAL_LENGTH_SIZE;

            mContent = null;
        }

        @Override
        public void addElement(ElementBase child) {
            // Does nothing.
        }

        public int getIndex() {
            return mIndex;
        }

        public void setIndex(int index) {
            this.mIndex = index;
        }

        public int getBitrate() {
            return mBitrate;
        }

        public void setBitrate(int bitrate) {
            this.mBitrate = bitrate;
        }

        public String getCodecPrivateData() {
            return mCodecPrivateData;
        }

        public void setCodecPrivateData(String codecPrivateData) {
            this.mCodecPrivateData = codecPrivateData;
        }

        public int getMaxWidth() {
            return mMaxWidth;
        }

        public void setMaxWidth(int maxWidth) {
            this.mMaxWidth = maxWidth;
        }

        public int getMaxHeight() {
            return mMaxHeight;
        }

        public void setMaxHeight(int maxHeight) {
            this.mMaxHeight = maxHeight;
        }

        public int getSamplingRate() {
            return mSamplingRate;
        }

        public void setSamplingRate(int samplingRate) {
            this.mSamplingRate = samplingRate;
        }

        public int getChannels() {
            return mChannels;
        }

        public void setChannels(int channels) {
            this.mChannels = channels;
        }

        public int getPacketSize() {
            return mPacketSize;
        }

        public void setPacketSize(int packetSize) {
            this.mPacketSize = packetSize;
        }

        public int getAudioTag() {
            return mAudioTag;
        }

        public void setAudioTag(int audioTag) {
            this.mAudioTag = audioTag;
        }

        public int getBitPerSample() {
            return mBitPerSample;
        }

        public void setBitPerSample(int bitPerSample) {
            this.mBitPerSample = bitPerSample;
        }

        public String getFourCC() {
            return mFourCC;
        }

        public void setFourCC(String fourCC) {
            this.mFourCC = fourCC;
        }

        public int getNalUnitLengthField() {
            return mNalUnitLengthField;
        }

        public void setNalUnitLengthField(int nalUnitLengthField) {
            this.mNalUnitLengthField = nalUnitLengthField;
        }

        public String getContent() {
            return mContent;
        }

        public void setContent(String content) {
            this.mContent = content;
        }

        public boolean verifyAudioAttributes() {
            return mCodecPrivateData != null && mSamplingRate != -1 && mChannels != -1 &&
                    mPacketSize != -1 && mAudioTag != -1 && mBitPerSample != -1 && mFourCC != null;
        }

        public boolean verifyVideoAttributes() {
            return mCodecPrivateData != null && mMaxWidth != -1 && mMaxHeight != -1;
        }
    }

    public static class StreamFragmentElement implements ElementBase {
        private int mFragmentNumber;
        private long mFragmentDuration;
        private long mFragmentStartTime;
        private List<TrackFragmentElement> mFragmentElements;

        StreamFragmentElement() {
            mFragmentNumber = -1;
            mFragmentDuration = -1;
            mFragmentStartTime = -1;
            mFragmentElements = null;
        }

        @Override
        public void addElement(ElementBase child) {
            if (child instanceof TrackFragmentElement) {
                if (mFragmentElements == null) {
                    mFragmentElements = new ArrayList<TrackFragmentElement>();
                }

                mFragmentElements.add((TrackFragmentElement) child);
                return;
            }

            assert(false);
        }

        public int getFragmentNumber() {
            return mFragmentNumber;
        }

        public void setFragmentNumber(int fragmentNumber) {
            this.mFragmentNumber = fragmentNumber;
        }

        public long getFragmentDuration() {
            return mFragmentDuration;
        }

        public void setFragmentDuration(long fragmentDuration) {
            this.mFragmentDuration = fragmentDuration;
        }

        public long getFragmentStartTime() {
            return mFragmentStartTime;
        }

        public void setFragmentStartTime(long fragmentStartTime) {
            this.mFragmentStartTime = fragmentStartTime;
        }

        public boolean verify() {
            return mFragmentStartTime != -1l || mFragmentDuration != -1l;
        }

        public void mayEmulateStartTime(StreamFragmentElement prev) {
            if (mFragmentDuration != -1l && mFragmentStartTime == -1l) {
                if (prev != null) {
                    mFragmentStartTime = prev.mFragmentStartTime + prev.mFragmentDuration;
                } else {
                    mFragmentStartTime = 0;
                }
            }
        }

        public void mayEmulateDuration(StreamFragmentElement next) {
            if (mFragmentDuration == -1l && mFragmentStartTime != -1l) {
                if (next != null) {
                    mFragmentDuration = next.mFragmentStartTime - mFragmentStartTime;
                } else {
                    mFragmentDuration = 0;
                }
            }
        }
    }

    public static class TrackFragmentElement implements ElementBase {
        private int mIndex;
        private String mContent;

        TrackFragmentElement() {
            mIndex = -1;
            mContent = null;
        }

        @Override
        public void addElement(ElementBase child) {
            // Should not called.
            assert(false);
        }

        public int getIndex() {
            return mIndex;
        }

        public void setIndex(int index) {
            this.mIndex = index;
        }

        public String getContent() {
            return mContent;
        }

        public void setContent(String content) {
            this.mContent = content;
        }
    }

    public static class StreamElement implements ElementBase {
        private StreamType mType;
        private String mSubType;
        private long mTimeScale;
        private String mName;
        private int mChunks;
        private int mQualityLevels;
        private String mUrl;
        private int mMaxWidth;
        private int mMaxHeight;
        private int mDisplayWidth;
        private int mDisplayHeight;
        private String mParentStreamIndex;
        private boolean mManifestOutput;

        // from engine.
        private int mTrackId;

        private List<TrackElement> mTracks;
        private List<StreamFragmentElement> mFragments;

        private int[] mBitrates;
        private int mCurrentTrack;

        StreamElement() {
            mType = null;
            mSubType = null;
            mTimeScale = -1;
            mName = null;
            mChunks = 0;
            mQualityLevels = 0;
            mUrl = null;
            mMaxWidth = 0;
            mMaxHeight = 0;
            mDisplayWidth = 0;
            mDisplayHeight = 0;
            mParentStreamIndex = null;
            mManifestOutput = false;

            mTrackId = -1;
            mCurrentTrack = -1;
        }

        public int[] getBitrates() {
            if (mTracks == null) {
                return new int[0];
            }

            if (mBitrates == null) {
                mBitrates = new int[mTracks.size()];
                for (int i = 0; i < mTracks.size(); ++i) {
                    mBitrates[i] = mTracks.get(i).mBitrate;
                }
            }

            return mBitrates;
        }

        public String buildRequestUrl(int fragmentIndex) {
            assert(mTracks != null);
            assert(mFragments != null);
            assert(fragmentIndex < mFragments.size());

            // Initialize bitrates.
            getBitrates();

            return mUrl.replace(SmoothStreamingConstants.STR_BITRATE,
                              Integer.toString(mBitrates[mCurrentTrack]))
                      .replace(SmoothStreamingConstants.STR_START_TIME,
                              Long.toString(mFragments.get(fragmentIndex).mFragmentStartTime));
        }

        public void setTrackId(int trackId) {
            this.mTrackId = trackId;
        }

        public int getTrackId() {
            return mTrackId;
        }

        public void setCurrentTrack(int currentTrack) {
            this.mCurrentTrack = currentTrack;
        }

        public int getCurrentTrack() {
            return mCurrentTrack;
        }

        public StreamType getType() {
            return mType;
        }

        public void setType(StreamType type) {
            this.mType = type;
        }

        public String getSubType() {
            return mSubType;
        }

        public void setSubType(String subType) {
            this.mSubType = subType;
        }

        public long getTimeScale() {
            return mTimeScale;
        }

        public void setTimeScale(long timeScale) {
            this.mTimeScale = timeScale;
        }

        public String getName() {
            return mName;
        }

        public void setName(String name) {
            this.mName = name;
        }

        public int getChunks() {
            return mChunks;
        }

        public void setChunks(int chunks) {
            this.mChunks = chunks;
        }

        public int getQualityLevels() {
            return mQualityLevels;
        }

        public void setQualityLevels(int qualityLevels) {
            this.mQualityLevels = qualityLevels;
        }

        public String getUrl() {
            return mUrl;
        }

        public void setUrl(String url) {
            this.mUrl = url;
        }

        public int getMaxWidth() {
            return mMaxWidth;
        }

        public void setMaxWidth(int maxWidth) {
            this.mMaxWidth = maxWidth;
        }

        public int getMaxHeight() {
            return mMaxHeight;
        }

        public void setMaxHeight(int maxHeight) {
            this.mMaxHeight = maxHeight;
        }

        public int getDisplayWidth() {
            return mDisplayWidth;
        }

        public void setDisplayWidth(int displayWidth) {
            this.mDisplayWidth = displayWidth;
        }

        public int getDisplayHeight() {
            return mDisplayHeight;
        }

        public void setDisplayHeight(int displayHeight) {
            this.mDisplayHeight = displayHeight;
        }

        public String getParentStreamIndex() {
            return mParentStreamIndex;
        }

        public void setParentStreamIndex(String parentStreamIndex) {
            this.mParentStreamIndex = parentStreamIndex;
        }

        public boolean isManifestOutput() {
            return mManifestOutput;
        }

        public void setManifestOutput(boolean manifestOutput) {
            this.mManifestOutput = manifestOutput;
        }

        public List<TrackElement> getTracks() {
            return mTracks;
        }

        public List<StreamFragmentElement> getFragments() {
            return mFragments;
        }

        @Override
        public void addElement(ElementBase child) {
            if (child instanceof TrackElement) {
                if (mTracks == null) {
                    mTracks = new ArrayList<TrackElement>();
                }

                TrackElement tr = (TrackElement) child;

                // If index is missed, fill it manually.
                if (tr.mIndex == -1) {
                    tr.mIndex = mTracks.size();
                }

                switch (mType) {
                case STREAM_AUDIO:
                    assert(tr.verifyAudioAttributes());
                    break;
                case STREAM_VIDEO:
                    assert(tr.verifyVideoAttributes());
                    break;
                default:
                }
                mTracks.add((TrackElement) child);
                return;
            }

            if (child instanceof StreamFragmentElement) {
                if (mFragments == null) {
                    mFragments = new ArrayList<StreamFragmentElement>();
                }

                StreamFragmentElement sf = (StreamFragmentElement) child;
                if (!sf.verify()) {
                    assert(false);
                    return;
                }

                // Adjust duration and start time.
                StreamFragmentElement prev = null;
                if (mFragments.size() > 0) {
                    prev = mFragments.get(mFragments.size() - 1);
                    prev.mayEmulateDuration(sf);
                }

                sf.mayEmulateStartTime(prev);

                mFragments.add((StreamFragmentElement) child);
                return;
            }

            // Should not be called.
            assert(false);
        }
    }

    public static class SmoothStreamingMedia implements ElementBase {
        SmoothStreamingMedia() {
            mMajorVersion = -1;
            mMinorVersion = -1;
            mTimeScale = 10000000l;
            mDuration = -1l;
            mIsLive = false;
            mLookAheadCount = -1;
            mDvrWindowLength = -1;
        }

        private int mMajorVersion;
        private int mMinorVersion;
        private long mTimeScale;
        private long mDuration;
        private boolean mIsLive;
        private int mLookAheadCount;
        private int mDvrWindowLength;

        private ProtectionElement mProtectionElement;
        private List<StreamElement> mStreamElements;

        @Override
        public void addElement(ElementBase child) {
            if (child instanceof ProtectionElement) {
                assert(mProtectionElement == null);
                mProtectionElement = (ProtectionElement) child;
                return;
            }

            if (child instanceof StreamElement) {
                if (mStreamElements == null) {
                    mStreamElements = new ArrayList<StreamElement>();
                }

                StreamElement s = (StreamElement) child;
                if (s.mTimeScale == -1) {
                    s.mTimeScale = mTimeScale;
                }
                mStreamElements.add(s);
                return;
            }

            // Should not be called.
            assert(false);
        }

        public int getMajorVersion() {
            return mMajorVersion;
        }

        public void setMajorVersion(int majorVersion) {
            this.mMajorVersion = majorVersion;
        }

        public int getMinorVersion() {
            return mMinorVersion;
        }

        public void setMinorVersion(int minorVersion) {
            this.mMinorVersion = minorVersion;
        }

        public long getTimeScale() {
            return mTimeScale;
        }

        public void setTimeScale(long timeScale) {
            this.mTimeScale = timeScale;
        }

        public long getDuration() {
            return mDuration;
        }

        public void setDuration(long duration) {
            this.mDuration = duration;
        }

        public boolean isLive() {
            return mIsLive;
        }

        public void setLive(boolean isLive) {
            this.mIsLive = isLive;
        }

        public int getLookAheadCount() {
            return mLookAheadCount;
        }

        public void setLookAheadCount(int lookAheadCount) {
            this.mLookAheadCount = lookAheadCount;
        }

        public int getDvrWindowLength() {
            return mDvrWindowLength;
        }

        public void setDvrWindowLength(int dvrWindowLength) {
            this.mDvrWindowLength = dvrWindowLength;
        }

        public ProtectionElement getProtectionElement() {
            return mProtectionElement;
        }

        public void setProtectionElement(ProtectionElement protectionElement) {
            this.mProtectionElement = protectionElement;
        }

        public List<StreamElement> getStreamElements() {
            return mStreamElements;
        }

        public void setStreamElements(List<StreamElement> streamElements) {
            this.mStreamElements = streamElements;
        }
    }

    private SmoothStreamingManifest() {}
}
