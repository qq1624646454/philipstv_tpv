/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import com.google.android.tv.media.TrackMetadata;

public final class SmoothStreamingConstants {
    public enum StreamType {
        STREAM_AUDIO(0),
        STREAM_VIDEO(1),
        STREAM_TEXT(2);

        StreamType(int index) {
            this.mIndex = index;
        }

        int asIndex() {
            return mIndex;
        }

        static StreamType valueOf(int index) {
            for (StreamType type : values()) {
                if (type.mIndex == index) {
                    return type;
                }
            }
            throw new IllegalArgumentException();
        }

        private int mIndex;
    }

    public enum SourceType {
        H264("H264", TrackMetadata.MEDIA_MIMETYPE_VIDEO_AVC),
        AVC1("AVC1", TrackMetadata.MEDIA_MIMETYPE_VIDEO_AVC),
        DAVC("DAVC", TrackMetadata.MEDIA_MIMETYPE_VIDEO_AVC),
        MPEG2ADTS("AACL", TrackMetadata.MEDIA_MIMETYPE_AUDIO_AAC),
        UNSUPPORTED("unsuported", "");

        private String mFourcc;
        private String mMimeType;

        SourceType(String fourcc, String mimeType) {
            this.mFourcc = fourcc;
            this.mMimeType = mimeType;
        }

        public String getMimiType() {
            return mMimeType;
        }

        public static SourceType fromFourcc(String fourcc) {
            for (SourceType type : SourceType.values()) {
                if (type.mFourcc.equalsIgnoreCase(fourcc)) {
                    return type;
                }
            }

            return UNSUPPORTED;
        }
    }

    public static final int SS_START = 1;
    public static final int SS_MONITOR_QUEUE = 2;
    public static final int SS_REQUEST_DOWNLOAD = 3;
    public static final int SS_USE_TRACK = 4;
    public static final int SS_UNUSE_TRACK = 5;

    public static final int DEFAULT_NAL_LENGTH_SIZE = 4;

    public static final String STR_START_TIME = "{start time}";
    public static final String STR_BITRATE = "{bitrate}";

    // Smooth streaming media
    public static final String KEY_SMOOTH_STREAMING_MEDIA = "SmoothStreamingMedia";

    // Child tags of smooth streaming media
    public static final String KEY_PROTECTION = "Protection";
    public static final String KEY_STREAM_ELEMENT = "StreamIndex";

    // Child tag of protection element
    public static final String KEY_PROTECTION_HEADER = "ProtectionHeader";

    // Child tags of stream element
    public static final String KEY_TRACK_ELEMENT = "QualityLevel";
    public static final String KEY_STREAM_FRAGMENT = "c";

    // Attributes of smooth streaming media
    public static final String KEY_MAJOR_VERSION = "MajorVersion";
    public static final String KEY_MINOR_VERSION = "MinorVersion";
    public static final String KEY_TIME_SCALE = "TimeScale";     // also used in stream element
    public static final String KEY_DURATION = "Duration";
    public static final String KEY_IS_LIVE = "IsLive";
    public static final String KEY_LOOKAHEAD_COUNT = "LookaheadCount";
    public static final String KEY_DVR_WINDOW_LENGTH = "DVRWindowLength";

    // Attribute of protection header
    public static final String KEY_SYSTEM_ID = "SystemID";

    // Attributes and values of stream element
    public static final String KEY_TYPE = "Type";
    public static final String KEY_TYPE_AUDIO = "audio";
    public static final String KEY_TYPE_VIDEO = "video";
    public static final String KEY_TYPE_TEXT = "text";
    public static final String KEY_SUB_TYPE = "Subtype";
    public static final String KEY_NAME = "Name";
    public static final String KEY_CHUNKS = "Chunks";
    public static final String KEY_QUALITY_LEVELS = "QualityLevels";
    public static final String KEY_URL = "Url";
    public static final String KEY_MAX_WIDTH= "MaxWidth";       // also used in track element
    public static final String KEY_MAX_HEIGHT = "MaxHeight";     // also used in track element
    public static final String KEY_DISPLAY_WIDTH = "DisplayWidth";
    public static final String KEY_DISPLAY_HEIGHT = "DisplayHeight";
    public static final String KEY_PARENT_STREAM_INDEX = "ParentStreamIndex";
    public static final String KEY_MANIFEST_OUTPUT = "ManifestOutput";
    public static final String KEY_TRUE = "true";
    public static final String KEY_FALSE = "false";

    // Attributes of track element
    public static final String KEY_INDEX = "Index";
    public static final String KEY_BITRATE = "Bitrate";
    public static final String KEY_CODEC_PRIVATE_DATA = "CodecPrivateData";
    public static final String KEY_SAMPLING_RATE = "SamplingRate";
    public static final String KEY_CHANNELS = "Channels";
    public static final String KEY_BITS_PER_SAMPLE = "BitsPerSample";
    public static final String KEY_PACKET_SIZE = "PacketSize";
    public static final String KEY_AUDIO_TAG = "AudioTag";
    public static final String KEY_FOUR_CC = "FourCC";
    public static final String KEY_NAL_UNIT_LENGTH_FIELD = "NALUnitLengthField";
    public static final String KEY_CONTENT = "Content";

    // Attributes of stream fragment
    public static final String KEY_FRAGMENT_NUMBER = "n";
    public static final String KEY_FRAGMENT_DURATION = "d";
    public static final String KEY_FRAGMENT_START_TIME = "t";
    public static final String KEY_TRACK_FRAGMENT_ELEMENT = "f";
    public static final String KEY_TRACK_FRAGMENT_INDEX = "i";

    public static final String KEY_META_FORM_MANIFEST = "MetaFromManifest";

    private SmoothStreamingConstants() {}
}
