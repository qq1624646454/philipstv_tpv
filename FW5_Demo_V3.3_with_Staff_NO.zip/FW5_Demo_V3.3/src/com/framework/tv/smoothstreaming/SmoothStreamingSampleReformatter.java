/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import com.framework.tv.smoothstreaming.SmoothStreamingFragmentParser.SampleInfo;
import com.framework.tv.smoothstreaming.SmoothStreamingFragmentParser.TrackInfo;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamFragmentElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.TrackElement;

import android.util.Log;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class SmoothStreamingSampleReformatter {
    protected final StreamElement mStreamElement;

    protected SmoothStreamingSampleReformatter(StreamElement streamElement) {
        this.mStreamElement = streamElement;
    }

    // Allocate buffer.
    public List<SmoothStreamSample> reformatSamples(TrackInfo track, ByteBuffer rawBuffer,
            int fragmentIndex, int qualityLevel) {
        StreamFragmentElement fragment = mStreamElement.getFragments().get(fragmentIndex);

        long fragmentStartTime = fragment.getFragmentStartTime();
        long timeScale = mStreamElement.getTimeScale();
        long elapsed = 0;
        List<SmoothStreamSample> newSamples = new ArrayList<SmoothStreamSample>(
                track.mSamples.size());
        for (SampleInfo sample : track.mSamples) {
            SmoothStreamSample newSample = SmoothStreamSample.create(sample.mSize);

            // copy buffer.
            rawBuffer.position(sample.mPosition);
            rawBuffer.get(newSample.buffer.array(), 0, sample.mSize);

            newSample.cryptoInfo = sample.mCryptoInfo;

            // calculate start time and duration.
            newSample.startTime = SmoothStreamingUtil.convertTimeInUs(
                    fragmentStartTime + elapsed + sample.mCompositionTimeOffset, timeScale);

            newSample.duration = SmoothStreamingUtil.convertTimeInUs(
                    sample.mDuration, timeScale);
            elapsed += sample.mDuration;

            newSamples.add(newSample);
        }

        return newSamples;
    }

    public SmoothStreamSample createStartFrame(int currentTrack, int fragmentIndex) {
        return null;
    }

    private static class AVCReformatter extends SmoothStreamingSampleReformatter {

        private static final int kMaxNALNumberPerSample = 100;

        private AVCReformatter(StreamElement streamElement) {
            super(streamElement);
        }

        @Override
        public List<SmoothStreamSample> reformatSamples(TrackInfo track, ByteBuffer rawBuffer,
                int fragmentIndex, int qualityLevel) {
            StreamFragmentElement fragment = mStreamElement.getFragments().get(fragmentIndex);
            long timeScale = mStreamElement.getTimeScale();

            long elapsed = 0;
            long fragmentStartTime = fragment.getFragmentStartTime();

            List<SmoothStreamSample> newSamples = new ArrayList<SmoothStreamSample>(
                    track.mSamples.size());

            int nalLengthSize = mStreamElement.getTracks().get(qualityLevel)
                    .getNalUnitLengthField();

            for (SampleInfo sample : track.mSamples) {
                int size = sample.mSize + kMaxNALNumberPerSample * 4;
                SmoothStreamSample newSample = SmoothStreamSample.create(size);

                // copy buffer.
                rawBuffer.position(sample.mPosition);
                convertNALDelimiter(rawBuffer, newSample.buffer, sample.mSize, nalLengthSize);

                // calculate start time.
                newSample.startTime = SmoothStreamingUtil.convertTimeInUs(
                        fragmentStartTime + elapsed + sample.mCompositionTimeOffset, timeScale);

                // We assume that nalLengthSize is always 4.
                assert(nalLengthSize == 4);
                newSample.cryptoInfo = sample.mCryptoInfo;

                // calculate duration.
                newSample.duration = SmoothStreamingUtil
                        .convertTimeInUs(sample.mDuration, timeScale);
                elapsed += sample.mDuration;

                newSamples.add(newSample);
            }

            return newSamples;
        }

        private void convertNALDelimiter(ByteBuffer rawBuffer, ByteBuffer newBuffer,
                int leftSize, int nalLengthSize) {
            int nalLength;
            int offset = 0;
            int nalCount = 0;
            while (leftSize > nalLengthSize) {
                // read NAL length
                nalLength = (rawBuffer.get() & 0xff);

                for (int i = 1; i < nalLengthSize; ++i) {
                    nalLength <<= 8;
                    nalLength |= (rawBuffer.get() & 0xff);
                }

                leftSize -= nalLengthSize;
                if (nalLength > leftSize) {
                    Log.e("AVCReformatter", "Nal length is larger than leftsize");
                    break;
                }

                newBuffer.put((byte) 0x00);
                newBuffer.put((byte) 0x00);
                newBuffer.put((byte) 0x00);
                newBuffer.put((byte) 0x01);
                offset += 4;

                rawBuffer.get(newBuffer.array(), offset, nalLength);
                offset += nalLength;
                newBuffer.position(offset);
                leftSize -= nalLength;

                nalCount++;
            }

            newBuffer.position(0);
            newBuffer.limit(offset);
        }

        @Override
        public SmoothStreamSample createStartFrame(int currentTrack, int fragmentIndex) {
            String codec = mStreamElement.getTracks().get(currentTrack).getCodecPrivateData();
            StreamFragmentElement fragment = mStreamElement.getFragments().get(fragmentIndex);

            long fragmentStartTime = fragment.getFragmentStartTime();
            long timeScale = mStreamElement.getTimeScale();

            SmoothStreamSample sample = SmoothStreamSample.create(codec.length() / 2);
            sample.duration = 0;
            sample.startTime = SmoothStreamingUtil.convertTimeInUs(
                    fragmentStartTime, timeScale);
            for (int i = 0; i < codec.length(); i += 2) {
                Integer value = Integer.parseInt(codec.substring(i, i + 2), 16);
                sample.buffer.put(value.byteValue());
            }
            sample.isCodecSpecificData = true;
            sample.buffer.flip();
            return sample;
        }
    }

    private static class MPEG2ADTSReformatter extends SmoothStreamingSampleReformatter {
        private static final int[] sSamplingRate = {
                96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050,
                16000, 12000, 11025, 8000
        };
        private static final int sADTHeaderSize = 7;

        protected MPEG2ADTSReformatter(StreamElement streamElement) {
            super(streamElement);
        }

        @Override
        public List<SmoothStreamSample> reformatSamples(TrackInfo track, ByteBuffer rawBuffer,
                int fragmentIndex, int qualityLevel) {
            StreamFragmentElement fragment = mStreamElement.getFragments().get(fragmentIndex);
            TrackElement trackElement = mStreamElement.getTracks().get(qualityLevel);

            List<SmoothStreamSample> newSamples = new ArrayList<SmoothStreamSample>(
                    track.mSamples.size());
            long elapsed = 0;
            long fragmentStartTime = fragment.getFragmentStartTime();
            long timeScale = mStreamElement.getTimeScale();
            for (SampleInfo sample : track.mSamples) {
                int size = sample.mSize + sADTHeaderSize;
                SmoothStreamSample newSample = SmoothStreamSample.create(size);

                rawBuffer.position(sample.mPosition);
                addADTHeader(newSample.buffer, sample.mSize, trackElement.getSamplingRate(),
                        trackElement.getChannels());
                rawBuffer.get(newSample.buffer.array(), sADTHeaderSize, size - sADTHeaderSize);

                // calculate start time.
                newSample.startTime = SmoothStreamingUtil.convertTimeInUs(
                        fragmentStartTime + elapsed + sample.mCompositionTimeOffset, timeScale);

                newSample.cryptoInfo = sample.mCryptoInfo;
                if (newSample.cryptoInfo != null &&
                        newSample.cryptoInfo.numBytesOfClearData.length != 0) {
                    // Considers the ADTS header as a clear data.
                    newSample.cryptoInfo.numBytesOfClearData[0] += 7;
                }

                // calculate duration.
                newSample.duration = SmoothStreamingUtil
                        .convertTimeInUs(sample.mDuration, timeScale);
                elapsed += sample.mDuration;

                newSample.buffer.limit(size);
                newSample.buffer.position(0);

                newSamples.add(newSample);
            }

            return newSamples;
        }

        private void addADTHeader(ByteBuffer buffer, int frameSize, int samplingRate,
                int channelCount) {
            buffer.put((byte) 0xff);

            byte b = (byte) (0xf0 | 1);
            buffer.put(b);

            int samplingIndex = getSamplingRateIndex(samplingRate);
            assert(samplingIndex != -1);
            b = (byte) ((0x01 << 6) | (samplingIndex << 2) | (channelCount >> 2));
            buffer.put(b);

            int frameLength = frameSize;
            b = (byte) ((channelCount << 6) | (frameLength >> 11));
            buffer.put(b);

            b = (byte) (frameLength >> 3);
            buffer.put(b);

            // adts_buffer_fullness 11 0x7FF
            b = (byte) ((frameLength << 5) | (0x7ff >> 6));
            buffer.put(b);

            b = (byte) (0x7ff << 2);
            buffer.put(b);
        }

        private int getSamplingRateIndex(int samplingRate) {
            for (int i = 0; i < sSamplingRate.length; ++i) {
                if (sSamplingRate[i] == samplingRate) {
                    return i;
                }
            }
            return -1;
        }
    }

    public static SmoothStreamingSampleReformatter create(StreamElement s) {
        SmoothStreamingConstants.SourceType type = SmoothStreamingConstants.SourceType
                .fromFourcc(s.getTracks().get(0).getFourCC());
        switch (type) {
            case AVC1:
            case H264:
            case DAVC:
                return new AVCReformatter(s);
            case MPEG2ADTS:
                return new MPEG2ADTSReformatter(s);
            default:
                return new SmoothStreamingSampleReformatter(s);
        }
    }
}
