/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import com.framework.tv.smoothstreaming.SmoothStreamingConstants.StreamType;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.ElementBase;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.ProtectionElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.ProtectionHeaderElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.SmoothStreamingMedia;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamFragmentElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.TrackElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.TrackFragmentElement;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class SmoothStreamingIsmParser {

    private static interface ElementParser {
        ElementBase parseStartTag(XmlPullParser parser);
        void parseText(XmlPullParser parser);
        ElementBase parseEndTag(XmlPullParser parser);
    }

    private static class SmoothStreamMediaParser implements ElementParser {
        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mMeta = new SmoothStreamingMedia();
            String value;

            try {
                // Required
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_MAJOR_VERSION);
                if (value != null) {
                    mMeta.setMajorVersion(Integer.parseInt(value));
                } else {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_MAJOR_VERSION);
                }

                // Required
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_MINOR_VERSION);
                if (value != null) {
                    mMeta.setMinorVersion(Integer.parseInt(value));
                } else {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_MINOR_VERSION);
                }

                // Required
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_DURATION);
                if (value != null) {
                    mMeta.setDuration(Long.parseLong(value));
                } else {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_DURATION);
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_TIME_SCALE);
                if (value != null) {
                    mMeta.setTimeScale(Long.parseLong(value));
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_IS_LIVE);
                if (value != null) {
                    if (SmoothStreamingConstants.KEY_TRUE.equals(value)) {
                        mMeta.setLive(true);
                    } else if (SmoothStreamingConstants.KEY_FALSE.equals(value)) {
                        mMeta.setLive(false);
                    } else {
                        throw new SmoothStreamingParseException("Invalid boolean value["
                                + SmoothStreamingConstants.KEY_IS_LIVE + "]");
                    }
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_LOOKAHEAD_COUNT);
                if (value != null) {
                    mMeta.setLookAheadCount(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_DVR_WINDOW_LENGTH);
                if (value != null) {
                    mMeta.setDvrWindowLength(Integer.parseInt(value));
                }

                // Vendor extension here.
            } catch (NumberFormatException e) {
                throw new SmoothStreamingParseException(e);
            }

            return mMeta;
        }

        @Override
        public void parseText(XmlPullParser parser) {
            // No text data.
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mMeta;
        }

        private SmoothStreamingMedia mMeta;
    }

    private static class ProtectionElementParser implements ElementParser {
        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mElement = new ProtectionElement();
            return mElement;
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mElement;
        }

        @Override
        public void parseText(XmlPullParser parser) {
            // Does nothing.
        }

        private ProtectionElement mElement;
    }

    private static class ProtectionHeaderElementParser implements ElementParser {
        private ProtectionHeaderElement mHeader;

        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mHeader = null;
            mHeader = new ProtectionHeaderElement();
            String value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_SYSTEM_ID);
            if (value != null) {
                mHeader.setSystemId(value);
            }
            return mHeader;
        }

        @Override
        public void parseText(XmlPullParser parser) {
            mHeader.setHeaderContent(parser.getText());
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mHeader;
        }
    }

    private static class StreamElementParser implements ElementParser {

        private StreamElement mElement;

        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mElement = new StreamElement();

            String value;
            try {
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_TYPE);
                if (value != null) {
                    if (SmoothStreamingConstants.KEY_TYPE_AUDIO.equalsIgnoreCase(value)) {
                        mElement.setType(StreamType.STREAM_AUDIO);
                    } else if (SmoothStreamingConstants.KEY_TYPE_VIDEO.equalsIgnoreCase(value)) {
                        mElement.setType(StreamType.STREAM_VIDEO);
                    } else if (SmoothStreamingConstants.KEY_TYPE_TEXT.equalsIgnoreCase(value)) {
                        mElement.setType(StreamType.STREAM_TEXT);
                    } else {
                        throw new SmoothStreamingParseException(
                                "Invalid key value[" + value + "]");
                    }
                }

                // Required
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_SUB_TYPE);
                if (value != null) {
                    mElement.setSubType(value);
                } else if (mElement.getType() == StreamType.STREAM_TEXT) {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_SUB_TYPE);
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_TIME_SCALE);
                // If not exist, use parent's time scale?
                if (value != null) {
                    mElement.setTimeScale(Long.parseLong(value));
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_NAME);
                if (value != null) {
                    mElement.setName(value);
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_CHUNKS);
                if (value != null) {
                    mElement.setChunks(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_QUALITY_LEVELS);
                if (value != null) {
                    mElement.setQualityLevels(Integer.parseInt(value));
                }

                // Required
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_URL);
                if (value != null) {
                    mElement.setUrl(value);
                } else {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_URL);
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_MAX_WIDTH);
                if (value != null) {
                    if (mElement.getType() != StreamType.STREAM_VIDEO) {
                        throw new SmoothStreamingMissingFieldException(
                                SmoothStreamingConstants.KEY_MAX_WIDTH);
                    }
                    mElement.setMaxWidth(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_MAX_HEIGHT);
                if (value != null) {
                    if (mElement.getType() != StreamType.STREAM_VIDEO) {
                        throw new SmoothStreamingMissingFieldException(
                                SmoothStreamingConstants.KEY_MAX_HEIGHT);
                    }
                    mElement.setMaxHeight(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_DISPLAY_WIDTH);
                if (value != null) {
                    if (mElement.getType() != StreamType.STREAM_VIDEO) {
                        throw new SmoothStreamingMissingFieldException(
                                SmoothStreamingConstants.KEY_DISPLAY_WIDTH);
                    }
                    mElement.setDisplayWidth(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_DISPLAY_HEIGHT);
                if (value != null) {
                    if (mElement.getType() != StreamType.STREAM_VIDEO) {
                        throw new SmoothStreamingMissingFieldException(
                                SmoothStreamingConstants.KEY_DISPLAY_HEIGHT);
                    }
                    mElement.setDisplayHeight(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_PARENT_STREAM_INDEX);
                if (value != null) {
                    mElement.setParentStreamIndex(value);
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_MANIFEST_OUTPUT);
                if (value != null) {
                    if (SmoothStreamingConstants.KEY_TRUE.equalsIgnoreCase(value)) {
                        mElement.setManifestOutput(true);
                    } else if (SmoothStreamingConstants.KEY_FALSE.equalsIgnoreCase(value)) {
                        mElement.setManifestOutput(false);
                    } else {
                        throw new SmoothStreamingParseException("Invalid boolean type["
                                + SmoothStreamingConstants.KEY_MANIFEST_OUTPUT + "]");
                    }
                }
            } catch (NumberFormatException e) {
                throw new SmoothStreamingParseException(e);
            }

            // If needs vendor specific attribute add them here.

            return mElement;
        }

        @Override
        public void parseText(XmlPullParser parser) {
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mElement;
        }
    }

    private static class TrackElementParser implements ElementParser {

        private TrackElement mElement;

        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mElement = new TrackElement();

            String value;
            try {
                // Required fields.

                // This is required but it might be missed. Calculate this manually.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_INDEX);
                if (value != null) {
                    mElement.setIndex(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_BITRATE);
                if (value != null) {
                    mElement.setBitrate(Integer.parseInt(value));
                } else {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_BITRATE);
                }

                // Evaluate[video] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_MAX_WIDTH);
                if (value != null) {
                    mElement.setMaxWidth(Integer.parseInt(value));
                }

                // Evaluate[video] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_MAX_HEIGHT);
                if (value != null) {
                    mElement.setMaxHeight(Integer.parseInt(value));
                }

                // Evaluate[video|audio] this later.
                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_CODEC_PRIVATE_DATA);
                if (value != null) {
                    mElement.setCodecPrivateData(value);
                }

                // Evaluate[audio] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_SAMPLING_RATE);
                if (value != null) {
                    mElement.setSamplingRate(Integer.parseInt(value));
                }

                // Evaluate[audio] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_CHANNELS);
                if (value != null) {
                    mElement.setChannels(Integer.parseInt(value));
                }

                // Evaluate[audio] this later.
                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_BITS_PER_SAMPLE);
                if (value != null) {
                    mElement.setBitPerSample(Integer.parseInt(value));
                }

                // Evaluate[audio] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_PACKET_SIZE);
                if (value != null) {
                    mElement.setPacketSize(Integer.parseInt(value));
                }

                // Evaluate[audio] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_AUDIO_TAG);
                if (value != null) {
                    mElement.setAudioTag(Integer.parseInt(value));
                }

                // Evaluate[audio] this later.
                value = parser.getAttributeValue(null, SmoothStreamingConstants.KEY_FOUR_CC);
                if (value != null) {
                    mElement.setFourCC(value);
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_NAL_UNIT_LENGTH_FIELD);
                if (value != null) {
                    mElement.setNalUnitLengthField(Integer.parseInt(value));
                }
            } catch (NumberFormatException e) {
                throw new SmoothStreamingParseException(e);
            }

            return mElement;
        }

        @Override
        public void parseText(XmlPullParser parser) {
            mElement.setContent(parser.getText());
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mElement;
        }
    }

    private static class StreamFragmentElementParser implements ElementParser {

        private StreamFragmentElement mElement;

        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mElement = new StreamFragmentElement();

            String value;
            try {
                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_FRAGMENT_NUMBER);
                if (value != null) {
                    mElement.setFragmentNumber(Integer.parseInt(value));
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_FRAGMENT_DURATION);
                if (value != null) {
                    mElement.setFragmentDuration(Long.parseLong(value));
                }

                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_FRAGMENT_START_TIME);
                if (value != null) {
                    mElement.setFragmentStartTime(Long.parseLong(value));
                }
            } catch (NumberFormatException e) {
                throw new SmoothStreamingParseException(e);
            }

            return mElement;
        }

        @Override
        public void parseText(XmlPullParser parser) {
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mElement;
        }
    }

    private static class TrackFragmentElementParser implements ElementParser {

        private TrackFragmentElement mElement;

        @Override
        public ElementBase parseStartTag(XmlPullParser parser) {
            mElement = new TrackFragmentElement();

            String value;
            try {
                value = parser.getAttributeValue(
                        null, SmoothStreamingConstants.KEY_TRACK_FRAGMENT_INDEX);
                if (value != null) {
                    mElement.setIndex(Integer.parseInt(value));
                } else {
                    throw new SmoothStreamingMissingFieldException(
                            SmoothStreamingConstants.KEY_TRACK_FRAGMENT_INDEX);
                }
            } catch (NumberFormatException e) {
                throw new SmoothStreamingParseException(e);
            }

            return mElement;
        }

        @Override
        public void parseText(XmlPullParser parser) {
            mElement.setContent(parser.getText());
        }

        @Override
        public ElementBase parseEndTag(XmlPullParser parser) {
            return mElement;
        }
    }

    // ///////////////////////////////////////////////////////////////
    private SmoothStreamingMedia mMeta;
    private ElementParser mCurrentParser;
    private XmlPullParser mParser;
    private Map<String, ElementParser> mElementParsers;
    private Stack<ElementBase> mParentElements;

    public SmoothStreamingIsmParser() {
        mParser = null;
        mMeta = null;
        mCurrentParser = null;

        initElementParsers();
    }

    private XmlPullParser createParser() throws XmlPullParserException {
        if (mParser != null) {
            mParser = null;
        }

        XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
        return parserCreator.newPullParser();
    }

    private void initElementParsers() {
        mElementParsers = new HashMap<String, ElementParser>();
        mElementParsers.put(SmoothStreamingConstants.KEY_SMOOTH_STREAMING_MEDIA,
                            new SmoothStreamMediaParser());
        mElementParsers.put(SmoothStreamingConstants.KEY_PROTECTION,
                            new ProtectionElementParser());
        mElementParsers.put(SmoothStreamingConstants.KEY_PROTECTION_HEADER,
                            new ProtectionHeaderElementParser());
        mElementParsers.put(SmoothStreamingConstants.KEY_STREAM_ELEMENT,
                            new StreamElementParser());
        mElementParsers.put(SmoothStreamingConstants.KEY_TRACK_ELEMENT,
                            new TrackElementParser());
        mElementParsers.put(SmoothStreamingConstants.KEY_STREAM_FRAGMENT,
                            new StreamFragmentElementParser());
        mElementParsers.put(SmoothStreamingConstants.KEY_TRACK_FRAGMENT_ELEMENT,
                            new TrackFragmentElementParser());
    }

    private void resetParentElements() {
        mParentElements = null;
        mParentElements = new Stack<ElementBase>();
    }

    public SmoothStreamingMedia parse(String source) throws XmlPullParserException, IOException {
        mParser = createParser();
        mParser.setInput(new StringReader(source));
        resetParentElements();

        int eventType = mParser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            switch (eventType) {
            case XmlPullParser.START_DOCUMENT:
                break;
            case XmlPullParser.END_DOCUMENT:
                break;
            case XmlPullParser.START_TAG:
                parseStartTag();
                break;
            case XmlPullParser.END_TAG:
                parseEndTag();
                break;
            case XmlPullParser.TEXT:
                parseText();
                break;
            default:
                // Does nothing.
                break;
            }
            eventType = mParser.next();
        }

        return mMeta;
    }

    private void parseStartTag() {
        String name = mParser.getName();
        ElementParser elementParser = mElementParsers.get(mParser.getName());
        assert(elementParser != null);

        mCurrentParser = elementParser;

        ElementBase base = elementParser.parseStartTag(mParser);
        assert(base != null);
        mParentElements.push(base);
    }

    private void parseText() {
        if (mCurrentParser != null) {
            mCurrentParser.parseText(mParser);
        }
    }

    private void parseEndTag() {
        ElementParser elementParser = mElementParsers.get(mParser.getName());
        assert(elementParser != null);

        ElementBase child = elementParser.parseEndTag(mParser);
        assert(child != null);

        mParentElements.pop();

        ElementBase parent = mParentElements.isEmpty() ? null : mParentElements.peek();
        if (parent != null) {
            parent.addElement(child);
        } else if (child instanceof SmoothStreamingMedia) {
            mMeta = (SmoothStreamingMedia) child;
        }

        // Invalidate current parser.
        mCurrentParser = null;
    }
}
