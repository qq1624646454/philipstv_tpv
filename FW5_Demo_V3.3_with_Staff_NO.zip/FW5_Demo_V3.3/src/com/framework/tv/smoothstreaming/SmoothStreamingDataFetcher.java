/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class SmoothStreamingDataFetcher {

    private static final String TAG = SmoothStreamingDataFetcher.class.getCanonicalName();

    public interface DataBandwidthObserver {
        void notifyNewMeasurement(long duration, long size);
    }

    private static final int sReadingBufferCapacity = 1 << 10;
    private static final int sDataBufferCapacity = 1 << 24; // 16M

    private final ByteBuffer mReadingBuffer;
    private final ByteBuffer mDataBuffer;
    private DataBandwidthObserver mBandwidthObserver;

    public SmoothStreamingDataFetcher() {
        mReadingBuffer = ByteBuffer.allocateDirect(sReadingBufferCapacity);
        mDataBuffer = ByteBuffer.allocateDirect(sDataBufferCapacity);
    }

    public void setBandwidthObserver(DataBandwidthObserver bandwidthObserver) {
        this.mBandwidthObserver = bandwidthObserver;
    }

    public ByteBuffer getData(String uri) {
        URL url;

        Log.i(TAG, uri + " is requsted");
        try {
            url = new URL(uri);
        } catch (MalformedURLException e) {
            Log.e(TAG, uri + " is mal-formed url.");
            return null;
        }

        InputStream stream = null;
        try {
            stream = url.openStream();
        } catch (IOException e) {
            Log.e(TAG, "Can't open stream:" + uri);
            return null;
        }

        if (stream == null) {
            Log.e(TAG, "Can't open stream:" + uri);
            return null;
        }

        mDataBuffer.clear();

        int offset = 0;
        int length = 0;

        ReadableByteChannel channel = Channels.newChannel(stream);
        try {
            long start = System.nanoTime();
            while (channel.read(mReadingBuffer) > -1 &&
                    mDataBuffer.remaining() > mReadingBuffer.limit()) {
                mReadingBuffer.flip();

                reportBandwidthMeasurement(System.nanoTime() - start, mReadingBuffer.limit());
                mDataBuffer.put(mReadingBuffer);
                mReadingBuffer.clear();

                start = System.nanoTime();
            }
        } catch (IOException e) {
            Log.e(TAG, "Can't read data from " + uri);
            return null;
        }

        mDataBuffer.flip();
        return mDataBuffer;
    }

    private void reportBandwidthMeasurement(long duration, long size) {
        if (mBandwidthObserver != null) {
            mBandwidthObserver.notifyNewMeasurement(duration, size);
        }
    }
}
