/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;


import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.xmlpull.v1.XmlPullParserException;

import android.annotation.SuppressLint;
import android.content.Context;
import android.drm.DrmInfo;
import android.drm.DrmInfoRequest;
import android.drm.DrmManagerClient;
import android.drm.DrmStore.Action;
import android.drm.DrmStore.RightsStatus;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.framework.tv.smoothstreaming.SmoothStreamingManifest.ProtectionHeaderElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.SmoothStreamingMedia;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.TrackElement;
import com.google.android.tv.media.PullMediaSource;
import com.google.android.tv.media.TrackMetadata;


public class SmoothStreamingSource extends PullMediaSource {
    private static final String TAG = "SmoothStreamingSource";
    private static final int sWaitTimeMsForPreparingSeesion = 100;
    private static final int sDefaultWouldBlockMs = 10;
    private static final int sMaxDownloadTrial = 3;
    private static final String sPRKeyContentsPath = new String("PRContentPath");
    private static final String sPRKeyPlayReadyObject = new String("PRPlayReadyObject");
    private static final String sMimeTypePlayReady = new String("application/vnd.ms-playready");

    private SmoothStreamingIsmParser mIsmParser;
    private String mUrl;
    private SmoothStreamingManifest.SmoothStreamingMedia mMedia;
    private SmoothStreamingSessionManager mSessionManager;
    private Condition mFetcherHandlerReady;
    private Lock mHandlerLock;
    private StreamFetcherThread mHandlerThread;
    private SmoothStreamingDataFetcher mFetcher;
    private Context mContext;
    private DrmManagerClient mDrmManagerClient;

    public SmoothStreamingSource(String url, Context context) {
        mContext = context;
        mUrl = url;

        mHandlerLock = new ReentrantLock();
        mFetcher = new SmoothStreamingDataFetcher();
    }

    private String buildPath(String path) {
        if (path.startsWith("http://") || path.startsWith("https://")) {
            return path;
        }

        String basePath = mUrl;
        if (basePath.endsWith("/")) {
            basePath = mUrl.substring(0, mUrl.length() - 1);
        }

        String additional = path;
        if (additional.startsWith("/")) {
            additional = path.substring(1, path.length());
        }

        return basePath + "/" + additional;
    }

    private class StreamFetcherThread extends Thread {
        private static final long MONITOR_QUEUE_DELAY_MS = 200;

        private StreamFetcherThread() {
        }

        @Override
        public void run() {
            Looper.prepare();
            mSourceLooper = Looper.myLooper();

            mHandlerLock.lock();
            mSourceHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                    case SmoothStreamingConstants.SS_START:
                        onStart();
                        break;
                    case SmoothStreamingConstants.SS_MONITOR_QUEUE:
                        onMonitorQueue();
                        break;
                    case SmoothStreamingConstants.SS_REQUEST_DOWNLOAD:
                        onDownloadRequest(msg);
                        break;
                    case SmoothStreamingConstants.SS_USE_TRACK:
                        onUseTrack(msg);
                        break;
                    case SmoothStreamingConstants.SS_UNUSE_TRACK:
                        onUnuseTrack(msg);
                        break;
                    }
                }

                private void onUseTrack(Message msg) {
                    mSessionManager.useTrack(msg.arg1);
                }

                private void onUnuseTrack(Message msg) {
                    mSessionManager.unuseTrack(msg.arg1);
                }

                private void onStart() {
                    postMonitorQueue(0);
                }

                private void onMonitorQueue() {
                    mSessionManager.monitorSessionQueues();
                    postMonitorQueue(MONITOR_QUEUE_DELAY_MS);
                }

                private void postMonitorQueue(long wait) {
                    Message msg = this.obtainMessage(SmoothStreamingConstants.SS_MONITOR_QUEUE);
                    sendMessageDelayed(msg, wait);
                }

                private void onDownloadRequest(final Message msg) {
                    int trackId = msg.arg1;

                    SmoothStreamingDataRequest req = (SmoothStreamingDataRequest) msg.obj;
                    String url = buildPath(req.url);

                    ByteBuffer data = mFetcher.getData(url);
                    int downloadTrial = 1;
                    while ((data == null || data.limit() == 0) &&
                           downloadTrial < sMaxDownloadTrial) {
                        Log.i(TAG, "Retrying to download: " + url);
                        data = mFetcher.getData(url);
                        ++downloadTrial;
                    }

                    if (data == null || data.limit() == 0) {
                        Log.e(TAG, "Download failure: " + url);
                        //TODO: Notify error to NativePlayer and stop the media.
                    } else {
                        mSessionManager.handleStreamData(req, data);
                        postMonitorQueue(MONITOR_QUEUE_DELAY_MS);
                    }
                }
            };

            mFetcherHandlerReady.signal();
            mHandlerLock.unlock();

            Looper.loop();
        }

        private Handler mSourceHandler;
        private Looper mSourceLooper;
    }

    @Override
    public void onStart(MediaInfo mediaInfo) {
        resetHandlerThread();
        resetIsmParser();
        resetSessions();

        String path = buildPath("/Manifest");

        ByteBuffer buffer = mFetcher.getData(path);
        if (buffer == null) {
            // Failed.
            Log.e(TAG, "Failed to get data from " + path);
            return;
        }
        String data = SmoothStreamingUtil.decode(buffer);
        try {
            mMedia = mIsmParser.parse(data);
        } catch (XmlPullParserException e) {
            Log.e(TAG, "XmlPullParserException while parsing the manifest file");
            return;
        } catch (IOException e) {
            Log.e(TAG, "IOException while parsing the manifest file");
            return;
        }

        if (mMedia != null) {
            handleIsm(mMedia, mediaInfo);
        }

        Message msg = mHandlerThread.mSourceHandler.obtainMessage(
                SmoothStreamingConstants.SS_START);
        mHandlerThread.mSourceHandler.sendMessage(msg);
    }

    private void resetSessions() {
        mSessionManager.clearSessions();
    }

    private void resetHandlerThread() {
        if (mHandlerThread != null) {
            mHandlerThread.mSourceLooper.quit();
            mHandlerThread = null;
        }

        mHandlerThread = new StreamFetcherThread();
        mHandlerThread.setDaemon(true);

        mFetcherHandlerReady = mHandlerLock.newCondition();
        mHandlerThread.start();
        mHandlerLock.lock();
        try {
            mFetcherHandlerReady.await();
        } catch (InterruptedException e) {
            Log.w("SmoothStreamingSource", e.getMessage());
        } finally {
            mHandlerLock.unlock();
        }

        mSessionManager = new SmoothStreamingSessionManager(mHandlerThread.mSourceHandler);
        mFetcher.setBandwidthObserver(mSessionManager);
    }

    private void resetIsmParser() {
        if (mIsmParser != null) {
            mIsmParser = null;
        }

        mIsmParser = new SmoothStreamingIsmParser();
    }

    private void handleIsm(SmoothStreamingMedia media, MediaInfo mediaInfo) {
        mediaInfo.setDuration((int) media.getDuration() / 1000);
        mediaInfo.setSeekable(false);

        for (StreamElement e : media.getStreamElements()) {
            String mime = getMimeType(e);

            assert(!SmoothStreamingUtil.isNullOrEmptyString(mime));
            TrackMetadata track = null;
            switch (e.getType()) {
                case STREAM_AUDIO: {
                    track = mediaInfo.addTrack(TrackMetadata.TRACK_TYPE_AUDIO, e.getName());
                    track.setInteger(TrackMetadata.KEY_CHANNEL_COUNT,
                                          e.getTracks().get(0).getChannels());
                    track.setInteger(TrackMetadata.KEY_SAMPLE_RATE,
                                          e.getTracks().get(0).getSamplingRate());
                    track.setInteger(TrackMetadata.KEY_BITRATE,
                                          e.getTracks().get(0).getBitrate());
                    if (media.getProtectionElement() != null) {
                        track.setBoolean(TrackMetadata.KEY_IS_DRM, true);
                    }
                    break;
                }
                case STREAM_VIDEO: {
                    track = mediaInfo.addTrack(TrackMetadata.TRACK_TYPE_VIDEO, e.getName());
                    int displayHeight = e.getDisplayHeight();
                    if (displayHeight <= 0) {
                        for (TrackElement t : e.getTracks()) {
                            if (displayHeight < t.getMaxHeight()) {
                                displayHeight = t.getMaxHeight();
                            }
                        }
                    }
                    track.setInteger(TrackMetadata.KEY_HEIGHT, displayHeight);
                    int displayWidth = e.getDisplayWidth();
                    if (displayWidth <= 0) {
                        for (TrackElement t : e.getTracks()) {
                            if (displayWidth < t.getMaxWidth()) {
                                displayWidth = t.getMaxWidth();
                            }
                        }
                    }
                    track.setInteger(TrackMetadata.KEY_WIDTH, displayWidth);
                    if (media.getProtectionElement() != null) {
                        track.setBoolean(TrackMetadata.KEY_IS_DRM, true);
                    }
                    break;
                }
                case STREAM_TEXT: {
                    track = mediaInfo.addTrack(TrackMetadata.TRACK_TYPE_TEXT, e.getName());
                    break;
                }
                default: {
                    break;
                }
            }
            track.setString(TrackMetadata.KEY_MIME_TYPE, mime);

            int trackId = track.getInteger(TrackMetadata.KEY_TRACK_ID);
            e.setTrackId(trackId);
            mSessionManager.addNewSession(trackId, e);
        }

        if (media.getProtectionElement() != null) {
            ProtectionHeaderElement protectionHeader =
                    media.getProtectionElement().getProtectionHeader();
            if (protectionHeader != null && protectionHeader.getSystemId() != null) {
                UUID uuid = UUID.fromString(protectionHeader.getSystemId());
                ByteBuffer buffer = ByteBuffer.allocate(16);
                buffer.putLong(uuid.getMostSignificantBits());
                buffer.putLong(uuid.getLeastSignificantBits());
                mediaInfo.setDrmUuid(buffer.array());

                final UUID playReadyUuid = UUID.fromString("9a04f079-9840-4286-ab92-e65be0885f95");
                if (uuid != null && playReadyUuid.compareTo(uuid) == 0) {
                    mediaInfo.setDrmSessionId(mUrl.getBytes());
                    setupPlayReadyDrm(protectionHeader);
                } else {
                    Log.e(TAG, "Non-PR UUID is not supported.");
                }
            }
        }
    }


	private void setupPlayReadyDrm(ProtectionHeaderElement protectionHeader) {
        mDrmManagerClient = new DrmManagerClient(mContext);
        DrmInfoRequest registerRequest = new DrmInfoRequest(
                DrmInfoRequest.TYPE_REGISTRATION_INFO, sMimeTypePlayReady);
        registerRequest.put(sPRKeyContentsPath, mUrl);
        registerRequest.put(sPRKeyPlayReadyObject, protectionHeader.getHeaderContent());
        DrmInfo drmInfo = mDrmManagerClient.acquireDrmInfo(registerRequest);
        if (drmInfo == null) {
            Log.e("TAG", "PR DRM registeration is failed.");
            return;
        }

        int status = mDrmManagerClient.checkRightsStatus(mUrl, Action.PLAY);
        if (status != RightsStatus.RIGHTS_VALID && status != RightsStatus.RIGHTS_NOT_ACQUIRED) {
            Log.e("TAG", "DRM status is invaild.");
            return;
        }
    }

    public void setUrl(String url) {
        this.mUrl = url;
    }

    private String getMimeType(StreamElement e) {
        List<TrackElement> tracks = e.getTracks();
        if (tracks.isEmpty()) {
            return "";
        }

        String fourCC = tracks.get(0).getFourCC();
        SmoothStreamingConstants.SourceType type =
                SmoothStreamingConstants.SourceType.fromFourcc(fourCC);
        if (type == SmoothStreamingConstants.SourceType.UNSUPPORTED) {
            return "";
        }

        return type.getMimiType();
    }

    @Override
    protected AccessUnit onDequeueAccessUnit(int trackId) {
        if (mSessionManager.wouldBlock()) {
            return AccessUnit.createWillBlock(sWaitTimeMsForPreparingSeesion);
        }

        SmoothStreamSample sample = mSessionManager.dequeueSample(trackId);

        if (sample == null) {
            return AccessUnit.createWillBlock(sDefaultWouldBlockMs);
        }

        AccessUnitMetadata auMeta = new AccessUnitMetadata();
        auMeta.setLong(AccessUnitMetadata.PTS_TIME_US, sample.startTime);
        if (sample.cryptoInfo != null) {
            auMeta.setByteArray(AccessUnitMetadata.CRYPTO_INFO, sample.cryptoInfo.toByteArray());
        }
        if (sample.isCodecSpecificData) {
            auMeta.setBoolean(AccessUnitMetadata.IS_CODEC_SPECIFIC_DATA, true);
        }
        AccessUnit accessUnit = AccessUnit.createAccessUnit(sample.buffer, auMeta);
        return accessUnit;
    }

    @Override
    protected void onHandleDiscontinuity(TrackMetadata track) {
        // TODO: implement this
    }

    @Override
    protected void onSeekTo(long arg0) {
        // TODO: implement this
    }

    @Override
    protected void onDeselectTrack(TrackMetadata track) {
        Message msg = mHandlerThread.mSourceHandler.obtainMessage(
                SmoothStreamingConstants.SS_UNUSE_TRACK);
        msg.arg1 = track.getTrackId();
        mHandlerThread.mSourceHandler.sendMessage(msg);
    }

    @Override
    protected void onSelectTrack(TrackMetadata track) {
        Message msg = mHandlerThread.mSourceHandler.obtainMessage(
                SmoothStreamingConstants.SS_USE_TRACK);
        msg.arg1 = track.getTrackId();
        mHandlerThread.mSourceHandler.sendMessage(msg);
    }

    @Override
    protected void onRelease() {
        if (mDrmManagerClient != null) {
            DrmInfoRequest registerRequest = new DrmInfoRequest(
                    DrmInfoRequest.TYPE_UNREGISTRATION_INFO, sMimeTypePlayReady);
            registerRequest.put(sPRKeyContentsPath, mUrl);
            DrmInfo drmInfo = mDrmManagerClient.acquireDrmInfo(registerRequest);
            if (drmInfo == null) {
                Log.e("TAG", "PR DRM unregisteration is failed.");
            }
        }
        if (mHandlerThread != null) {
            mHandlerThread.mSourceLooper.quit();
            mHandlerThread = null;
        }
        mFetcher = null;
    }
}
