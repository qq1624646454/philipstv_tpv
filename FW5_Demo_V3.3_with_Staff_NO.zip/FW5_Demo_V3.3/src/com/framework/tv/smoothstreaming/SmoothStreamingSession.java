/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import com.framework.tv.smoothstreaming.SmoothStreamingConstants.StreamType;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamElement;
import com.framework.tv.smoothstreaming.SmoothStreamingManifest.TrackElement;

import android.os.Handler;
import android.os.Message;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class SmoothStreamingSession {
    private static final int sMaxBufferingSize = 3;

    private SmoothStreamingManifest.StreamElement mStreamInfo;
    private ConcurrentLinkedQueue<SmoothStreamSample> mQueue;
    private Handler mHandler;

    private Queue<Integer> mFrameHistory;
    private int mAllQueuedFrames;
    private int mRequested;
    private boolean mQualityChanged;
    private boolean mPacketReceived;
    private int mCurrentFragmentIndex;
    private volatile boolean mUsed;
    private final SmoothStreamingFragmentParser mParser;
    private final SmoothStreamingSampleReformatter mReformatter;

    private List<Integer> mBitrates;

    public SmoothStreamingSession(StreamElement streamInfo,
            Handler handler) {
        this.mQualityChanged = false;
        this.mPacketReceived = false;
        this.mStreamInfo = streamInfo;
        this.mHandler = handler;

        this.mReformatter = SmoothStreamingSampleReformatter.create(streamInfo);
        this.mQueue = new ConcurrentLinkedQueue<SmoothStreamSample>();
        this.mParser = new SmoothStreamingFragmentParser();

        mBitrates = new ArrayList<Integer>(streamInfo.getTracks().size());
        for (TrackElement track : streamInfo.getTracks()) {
            mBitrates.add(track.getBitrate());
        }

        reset();
    }

    public void reset() {
        mUsed = false;
        mPacketReceived = false;
        mFrameHistory = null;
        mFrameHistory = new LinkedList<Integer>();

        mAllQueuedFrames = 0;
        mCurrentFragmentIndex = 0;
        mRequested = 0;
    }

    public void setUsed(boolean used) {
        this.mUsed = used;
    }

    public long consumeBandwidth(long availableBandwidth, boolean useLowset) {
        int level = -1;
        int oldLevel = mStreamInfo.getCurrentTrack();
        if (useLowset) {
            level = mBitrates.size() - 1;
        } else {
            level = getProperBandwidthIndex(availableBandwidth);
        }

        if (oldLevel > level) {
            level = Math.max(oldLevel - 1, 0);
        } else if (oldLevel < level) {
            level = Math.min(oldLevel + 1, mBitrates.size() - 1);
        }

        if (oldLevel == -1) {
            level = mBitrates.size() - 1;
        }

        if (oldLevel != level) {
            // For the first round, just set level.
            setQualityLevel(level);
        }

        return Math.max(availableBandwidth - mBitrates.get(level), 0);
    }

    public void setQualityLevel(int level) {
        if (mStreamInfo.getCurrentTrack() != level) {
            mQualityChanged = true;
            mStreamInfo.setCurrentTrack(level);
        }
    }

    private int getProperBandwidthIndex(long availableBandwidth) {
        if (mCurrentFragmentIndex < sMaxBufferingSize) {
            return mBitrates.size() - 1;
        }

        for (int i = 0; i < mBitrates.size(); ++i) {
            if (availableBandwidth > mBitrates.get(i)) {
                return i;
            }
        }

        return mBitrates.size() - 1;
    }

    public boolean isReceived() {
        return mPacketReceived;
    }

    public void mayDownloadNext() {
        if (!shouldDownloadNext()) {
            return;
        }

        Message msg = Message.obtain();
        msg.what = SmoothStreamingConstants.SS_REQUEST_DOWNLOAD;
        msg.arg1 = mStreamInfo.getTrackId();
        msg.obj = buildRequest();

        mRequested++;
        mCurrentFragmentIndex++;

        mQualityChanged = false;
        if (mCurrentFragmentIndex == mStreamInfo.getFragments().size() - 1) {
            mUsed = false;
        }

        mHandler.sendMessage(msg);
    }

    private SmoothStreamingDataRequest buildRequest() {
        SmoothStreamingDataRequest request = new SmoothStreamingDataRequest();
        request.url = mStreamInfo.buildRequestUrl(mCurrentFragmentIndex);
        request.trackId = mStreamInfo.getTrackId();
        request.frameNo = mCurrentFragmentIndex;
        request.qualityLevel = mStreamInfo.getCurrentTrack();
        request.qualityChanged = mQualityChanged;
        return request;
    }

    public SmoothStreamSample dequeueSample() {
        return mQueue.poll();
    }

    public boolean isUsed() {
        return mUsed;
    }

    private boolean shouldDownloadNext() {
        if (!mUsed) {
            return false;
        }

        if (mRequested > sMaxBufferingSize - 1) {
            return false;
        }

        if (mFrameHistory.size() < sMaxBufferingSize) {
            return true;
        }

        int oldestFrames = mFrameHistory.peek();
        int size = mQueue.size();
        return mAllQueuedFrames - oldestFrames > mQueue.size();
    }

    private void updateFrameCount(int newFrames) {
        if (mFrameHistory.size() >= sMaxBufferingSize) {
            mAllQueuedFrames -= mFrameHistory.poll();
        }
        mFrameHistory.add(newFrames);
        mAllQueuedFrames += newFrames;
    }

    public StreamType getType() {
        return mStreamInfo.getType();
    }

    public void handleFragmentData(SmoothStreamingDataRequest req, ByteBuffer buffer) {
        if (req.qualityChanged) {
            SmoothStreamSample firstSample = mReformatter.createStartFrame(req.qualityLevel,
                    req.frameNo);
            if (firstSample != null) {
                List<SmoothStreamSample> samples = new ArrayList<SmoothStreamSample>(1);
                samples.add(firstSample);
                queueSamples(samples);
            }
        }

        SmoothStreamingFragmentParser.TrackInfo track = mParser.parse(buffer);
        queueSamples(mReformatter.reformatSamples(track, buffer, req.frameNo, req.qualityLevel));
        mRequested--;

        mPacketReceived = true;
    }

    public void queueSamples(List<SmoothStreamSample> samples) {
        updateFrameCount(samples.size());
        mQueue.addAll(samples);
    }
}
