/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import com.google.android.tv.media.MediaSource;
import com.google.android.tv.media.MediaSource.CryptoInfo;

import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SmoothStreamingFragmentParser {
    private static final String TAG = "SmoothStreamingFragmentParser";

    // Flags for a TFHD box
    private static final int sFlagTfhdBaseDataOffset = 0x000001;
    private static final int sFlagTfhdSampleDescriptionIndex = 0x000002;
    private static final int sFlagTfhdDefaultSampleDuration = 0x000008;
    private static final int sFlagTfhdDefaultSampleSize = 0x000010;
    private static final int sFlagTfhdDefaultSampleFlag = 0x000020;
    // Flags for a TRUN box
    private static final int sFlagTrunDataOffset = 0x000001;
    private static final int sFlagTrunFirstSampleFlags = 0x000004;
    private static final int sFlagTrunSampleDuration = 0x000100;
    private static final int sFlagTrunSampleSize = 0x000200;
    private static final int sFlagTrunSampleFlags = 0x000400;
    private static final int sFlagTrunSampleCompositionTimeOffsets = 0x000800;
    // Flags for a UUID box
    private static final int sFlagOverrideTrackEncryptionBox = 0x000001;
    private static final int sFlagUseSubSampleEncryption = 0x000002;

    public static class TrackInfo {
        int mFlag;

        int mTrackId;
        long mBaseOffset;
        int mSampleDescriptionIndex;
        int mDefaultSampleDuration;
        int mDefaultSampleSize;
        int mDefaultSampleFlags;

        int mSampleCount;
        int mDataOffset;

        List<SampleInfo> mSamples = new ArrayList<SampleInfo>();
    }

    public static class SampleInfo {
        long mDuration;
        int mSize;
        int mFlags;
        int mCompositionTimeOffset;
        // for decryption.
        CryptoInfo mCryptoInfo;

        int mPosition;
    }

    private enum BoxType {
        MOOF("moof"),
        MFHD("mfhd"),
        TRAF("traf"),
        TFHD("tfhd"),
        TRUN("trun"),
        UUID("uuid"),
        MDAT("mdat"),
        UNKNOWN("xxxx");

        BoxType(String str) {
            char[] chr = str.toCharArray();
            byte[] data = new byte[4];
            for (int i = 0; i < 4; ++i) {
                data[i] = (byte) chr[i];
            }

            type = bytesToInt(data);
        }

        public static int bytesToInt(byte data[]) {
            int value = 0;
            for (int i = 0; i < 4; ++i) {
                value |= (data[i] & 0x000000ff);
                if (i < 3) {
                    value <<= 8;
                }
            }

            return value;
        }

        public static BoxType valueOf(byte data[]) {
            int value = bytesToInt(data);

            for (BoxType boxType : BoxType.values()) {
                if (boxType.type == value) {
                    return boxType;
                }
            }
            return UNKNOWN;
        }

        private int type;
    }

    private TrackInfo mTrackInfo;

    public TrackInfo parse(ByteBuffer buffer) throws InvalidFormatException {
        parseMoofBox(buffer);
        parseMdatBox(buffer);

        return mTrackInfo;
    }

    private void parseMoofBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.MOOF);

        while (buffer.position() - start < size) {
            BoxType type = peekBoxType(buffer);
            switch (type) {
            case MFHD:
                parseMfhdBox(buffer);
                break;
            case TRAF:
                parseTrafBox(buffer);
                break;
            default:
                parseUnknownBox(buffer);
                break;
            }
        }

        buffer.position(start + size);
    }

    private void parseUnknownBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.UNKNOWN);

        Log.w(TAG, "Unknown BoxType");
        buffer.position(start + size);
    }

    private void parseMfhdBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.MFHD);

        // Reads sequence number.
        int seq = buffer.getInt();

        // Reads vendor specific data here.
        buffer.position(start + size);
    }

    private void parseTrafBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.TRAF);

        BoxType type = peekBoxType(buffer);

        // Assume that traf box starts with a trhd and follows zero or more trun
        // and vendor specific boxes.
        parseTfhdBox(buffer);

        while (buffer.position() - start < size) {
            switch (peekBoxType(buffer)) {
            case TRUN:
                parseTrunBox(buffer);
                break;
            case UUID:
                parseUuidBox(buffer);
                break;
            default:
                parseUnknownBox(buffer);
            }
        }

        buffer.position(start + size);
    }

    private void parseTfhdBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.TFHD);

        mTrackInfo = null;
        mTrackInfo = new TrackInfo();

        mTrackInfo.mFlag = readFullBoxFlag(buffer);
        mTrackInfo.mTrackId = buffer.getInt();

        if ((mTrackInfo.mFlag & sFlagTfhdBaseDataOffset) != 0) {
            mTrackInfo.mBaseOffset = buffer.getLong();
        }

        if ((mTrackInfo.mFlag & sFlagTfhdSampleDescriptionIndex) != 0) {
            mTrackInfo.mSampleDescriptionIndex = buffer.getInt();
        }

        if ((mTrackInfo.mFlag & sFlagTfhdDefaultSampleDuration) != 0) {
            mTrackInfo.mDefaultSampleDuration = buffer.getInt();
        }

        if ((mTrackInfo.mFlag & sFlagTfhdDefaultSampleSize) != 0) {
            mTrackInfo.mDefaultSampleSize = buffer.getInt();
        }

        if ((mTrackInfo.mFlag & sFlagTfhdDefaultSampleFlag) != 0) {
            mTrackInfo.mDefaultSampleFlags = buffer.getInt();
        }

        buffer.position(start + size);
    }

    private void parseTrunBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.TRUN);

        int flag = readFullBoxFlag(buffer);
        mTrackInfo.mSampleCount = buffer.getInt();

        if ((flag & sFlagTrunDataOffset) != 0) {
            mTrackInfo.mDataOffset = buffer.getInt();
        }

        int sampleFlags = mTrackInfo.mDefaultSampleFlags;
        if ((flag & sFlagTrunFirstSampleFlags) != 0) {
            sampleFlags = buffer.getInt();
        }

        for (int i = 0; i < mTrackInfo.mSampleCount; ++i) {
            SampleInfo sample = new SampleInfo();
            if ((flag & sFlagTrunSampleDuration) != 0) {
                sample.mDuration = buffer.getInt();
            } else {
                sample.mDuration = mTrackInfo.mDefaultSampleDuration;
            }

            if ((flag & sFlagTrunSampleSize) != 0) {
                sample.mSize = buffer.getInt();
            } else {
                sample.mSize = mTrackInfo.mDefaultSampleSize;
            }

            if ((flag & sFlagTrunSampleFlags) != 0) {
                sample.mFlags = buffer.getInt();
            } else {
                sample.mFlags = sampleFlags;
            }

            if ((flag & sFlagTrunSampleCompositionTimeOffsets) != 0) {
                sample.mCompositionTimeOffset = buffer.getInt();
            }

            mTrackInfo.mSamples.add(sample);
        }

        // Reads vendor specific trun data here.

        buffer.position(start + size);
    }

    private void parseUuidBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.UUID);

        byte[] sampleEncryptionBoxType = {
                (byte) 0xa2, 0x39, 0x4f, 0x52, 0x5a, (byte) 0x9b, 0x4f, 0x14,
                (byte) 0xa2, 0x44, 0x6c, 0x42, 0x7c, 0x64, (byte) 0x8d, (byte) 0xf4};
        byte[] type = new byte[16];
        buffer.get(type, 0, 16);
        if(!Arrays.equals(sampleEncryptionBoxType, type)) {
            throw new InvalidFormatException("encryptionBoxType in UUID box is not matched.");
        }
        int flag = readFullBoxFlag(buffer);
        if ((flag & sFlagOverrideTrackEncryptionBox) != 0) {
            // TODO: Implement this.
            Log.e(TAG, "Unsupported dynamic change of the algorithm.");
        }
        int sampleCount = buffer.getInt();
        if (sampleCount != mTrackInfo.mSampleCount) {
            throw new InvalidFormatException("Mismatch in the sample count.");
        }

        for (int i = 0; i < sampleCount; ++i) {
            CryptoInfo cryptoInfo = new CryptoInfo();
            // We assume that the mode is always CRYPTO_MODE_AES_CTR in SS.
            cryptoInfo.mode = CryptoInfo.MODE_AES_CTR;
            // TODO: Use drmId which gets from IsmParser.
            cryptoInfo.drmId = CryptoInfo.UUID_PLAYREADY;
            cryptoInfo.iv = new byte[16];
            cryptoInfo.key = new byte[16];
            // Convert BIG_ENDIAN to LITTLE_ENDIAN. (native order is LITTLE_ENDIAN.)
            ByteBuffer ivBuffer = ByteBuffer.wrap(cryptoInfo.iv);
            ivBuffer.order(ByteOrder.nativeOrder());
            ivBuffer.putLong(buffer.getLong());
            if ((flag & sFlagUseSubSampleEncryption) != 0) {
                int numSubSample = buffer.getShort();
                cryptoInfo.numSubSamples = numSubSample;
                cryptoInfo.numBytesOfClearData = new int[numSubSample];
                cryptoInfo.numBytesOfEncryptedData = new int[numSubSample];
                for (int j = 0; j < numSubSample; ++j) {
                    cryptoInfo.numBytesOfClearData[j] = buffer.getShort();
                    cryptoInfo.numBytesOfEncryptedData[j] = buffer.getInt();
                }
                mTrackInfo.mSamples.get(i).mCryptoInfo = cryptoInfo;
            } else {
                int numSubSample = 1;
                cryptoInfo.numSubSamples = numSubSample;
                cryptoInfo.numBytesOfClearData = new int[numSubSample];
                cryptoInfo.numBytesOfEncryptedData = new int[numSubSample];
                cryptoInfo.numBytesOfClearData[0] = 0;
                cryptoInfo.numBytesOfEncryptedData[0] = mTrackInfo.mSamples.get(i).mSize;
                mTrackInfo.mSamples.get(i).mCryptoInfo = cryptoInfo;
            }
        }
    }

    private int readFullBoxFlag(ByteBuffer buffer) {
        return buffer.getInt() & 0x00ffffff;
    }

    private int readBoxSize(ByteBuffer buffer, BoxType type) {
        int size = buffer.getInt();

        BoxType readType = readBoxType(buffer);
        if (type != BoxType.UNKNOWN && type != readType) {
            throw new InvalidFormatException(type.name() +
                    " does not match with " + readType.name());
        }

        if (size == 1) {
            // skip type(4 bytes) and read long value.
            // Currently only < 2Gb allowed.
            long longSize = buffer.getLong(buffer.position() + 4);
            if (longSize > 0x7fffffff) {
                throw new InvalidFormatException("We supports only less than 2gb size of chunk.");
            }
        }

        return size;
    }

    private BoxType peekBoxType(ByteBuffer buffer) {
        int start = buffer.position();
        // read length;
        buffer.getInt();
        BoxType type = readBoxType(buffer);
        buffer.position(start);
        return type;
    }

    private BoxType readBoxType(ByteBuffer buffer) {
        byte data[] = new byte[4];
        buffer.get(data);
        return BoxType.valueOf(data);
    }

    private void parseMdatBox(ByteBuffer buffer) {
        int start = buffer.position();
        int size = readBoxSize(buffer, BoxType.MDAT);

        for (SampleInfo s : mTrackInfo.mSamples) {
            s.mPosition = buffer.position();

            // In order to reduce the number of mem copy, just mark start
            // position of buffer here.
            buffer.position(s.mPosition + s.mSize);
        }

        buffer.position(start + size);
    }
}
