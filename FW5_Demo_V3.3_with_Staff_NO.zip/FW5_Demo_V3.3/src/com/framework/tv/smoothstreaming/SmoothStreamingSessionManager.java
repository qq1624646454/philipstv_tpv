/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framework.tv.smoothstreaming;

import android.os.Handler;
import android.util.Log;

import com.framework.tv.smoothstreaming.SmoothStreamingManifest.StreamElement;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class SmoothStreamingSessionManager implements
        SmoothStreamingDataFetcher.DataBandwidthObserver {

    private static final class BandwidthEntry {
        private final long mTransferTimeUs;
        private final long mTransferBytes;

        private BandwidthEntry(long transferTime, long transferBytes) {
            this.mTransferTimeUs = transferTime;
            this.mTransferBytes = transferBytes;
        }
    }

    private static final int sMaxHistory = 200;
    private volatile long mTotalTransferTimeNs;
    private volatile long mTotalTransferBytes;

    private final ConcurrentHashMap<Integer, SmoothStreamingSession> mSessionMap;
    private final Handler mHandler;
    private final List<BandwidthEntry> mBandwidthHistory;

    public SmoothStreamingSessionManager(Handler handler) {
        this.mHandler = handler;
        mSessionMap = new ConcurrentHashMap<Integer, SmoothStreamingSession>();

        mBandwidthHistory = new LinkedList<BandwidthEntry>();
        mTotalTransferBytes = 0;
        mTotalTransferTimeNs = 0;
    }

    // Called from handler thread.
    public void handleStreamData(SmoothStreamingDataRequest req, ByteBuffer data) {
        SmoothStreamingSession session = mSessionMap.get(req.trackId);
        if (session == null) {
            return;
        }

        session.handleFragmentData(req, data);
    }

    // Called from handler thread.
    public void monitorSessionQueues() {
        Collection<SmoothStreamingSession> sessions = mSessionMap.values();
        decideBandwidth(sessions);
        for (SmoothStreamingSession session : sessions) {
            session.mayDownloadNext();
        }
    }

    public boolean wouldBlock() {
        for (SmoothStreamingSession session : mSessionMap.values()) {
            if (!session.isUsed()) {
                continue;
            }
            if (!session.isReceived()) {
                return true;
            }
        }

        return false;
    }

    private void decideBandwidth(Collection<SmoothStreamingSession> sessions) {
        long bandwidth = getBandwidth();

        List<SmoothStreamingSession> topSessions = new ArrayList<SmoothStreamingSession>();
        List<SmoothStreamingSession> bottomSessions = new ArrayList<SmoothStreamingSession>();

        for (SmoothStreamingSession session : sessions) {
            switch (session.getType()) {
                case STREAM_AUDIO:
                case STREAM_TEXT:
                    topSessions.add(session);
                    break;
                case STREAM_VIDEO:
                    bottomSessions.add(session);
                    break;
                default:
                    Log.e("SmoothStreamingSessionManager", "Invalid type");
            }
        }

        bandwidth = consumeBandwidth(bandwidth, topSessions, false);
        if (bandwidth == 0) {
            consumeBandwidth(bandwidth, topSessions, true);
        }

        consumeBandwidth(bandwidth, bottomSessions, false);
    }

    private long consumeBandwidth(long bandwidth,
            List<SmoothStreamingSession> sessions, boolean useLowest) {
        for (SmoothStreamingSession session : sessions) {
            bandwidth = session.consumeBandwidth(bandwidth, useLowest);
        }
        return bandwidth;
    }

    public void clearSessions() {
        mSessionMap.clear();
    }

    // Called from main thread.
    public void addNewSession(int trackId, StreamElement e) {
        mSessionMap.put(trackId, new SmoothStreamingSession(e, mHandler));
    }

    // Called from main thread.
    public SmoothStreamSample dequeueSample(int trackId) {
        SmoothStreamingSession session = mSessionMap.get(trackId);
        assert(session != null);

        return session.dequeueSample();
    }

    // Called from handler thread.
    public void useTrack(int trackId) {
        SmoothStreamingSession session = mSessionMap.get(trackId);
        assert(session != null);

        session.setUsed(true);
    }

    // Called from handler thread.
    public void unuseTrack(int trackId) {
        SmoothStreamingSession session = mSessionMap.get(trackId);
        assert(session != null);

        session.setUsed(false);
    }

    // Called from both handler and main threads but called in order.
    @Override
    public void notifyNewMeasurement(long duration, long size) {
        if (mBandwidthHistory.size() > sMaxHistory) {
            BandwidthEntry oldest = mBandwidthHistory.remove(0);
            mTotalTransferBytes -= oldest.mTransferBytes;
            mTotalTransferTimeNs -= oldest.mTransferTimeUs;
            oldest = null;
        }

        mTotalTransferBytes += size;
        mTotalTransferTimeNs += duration;
        mBandwidthHistory.add(new BandwidthEntry(duration, size));
    }

    private long getBandwidth() {
        if (mTotalTransferTimeNs == 0) {
            return 0;
        }
        return mTotalTransferBytes * (1000000000l / mTotalTransferTimeNs);
    }
}
