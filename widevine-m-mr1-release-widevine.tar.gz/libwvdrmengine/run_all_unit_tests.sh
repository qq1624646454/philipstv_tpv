#!/bin/sh

final_result=0
failed_tests=()

# Below, we will append filters to the exclusion portion of GTEST_FILTER, so we
# need to guarantee it has one.
if [ -z "$GTEST_FILTER" ]; then
  # If it wasn't set, make it add all tests, and remove none.
  GTEST_FILTER="*-"
# if GTEST_FILTER already has a negative sign, we leave it alone.
elif [ 0 -eq `expr index "$GTEST_FILTER" "-"` ]; then
  # If GTEST_FILTER was set, but does not have a negative sign, add one.  This
  # gives gtest an empty list of tests to skip.
  GTEST_FILTER="$GTEST_FILTER-"
fi

# Execute a command in "adb shell" and capture the result.
adb_shell_run() {
  local tmp_log="$OUT/mediadrmtest.log"
  local adb_error="[ADB SHELL] $@ failed"
  adb shell "GTEST_FILTER=$GTEST_FILTER $@" \|\| echo "$adb_error" | tee "$tmp_log"
  ! grep -Fq "$adb_error" "$tmp_log"
  local result=$?
  if [ $result -ne 0 ]; then
    final_result=$result
    failed_tests+=("$adb_error")
  fi
}

if [ -z "$ANDROID_BUILD_TOP" ]; then
    echo "Android build environment not set"
    exit -1
fi

echo "waiting for device"
adb root && adb wait-for-device remount

adb_shell_run GTEST_FILTER="$GTEST_FILTER:*Level1Required" FORCE_LEVEL3_OEMCRYPTO=yes \
  /system/bin/oemcrypto_test
adb_shell_run /system/bin/oemcrypto_test
adb_shell_run /system/bin/request_license_test
# cdm_extended_duration_test takes >30 minutes to run.
# adb_shell_run /system/bin/cdm_extended_duration_test
adb_shell_run /system/bin/max_res_engine_unittest
adb_shell_run /system/bin/policy_engine_unittest
adb_shell_run /system/bin/libwvdrmmediacrypto_test
adb_shell_run /system/bin/libwvdrmdrmplugin_test
adb_shell_run /system/bin/cdm_engine_test
adb_shell_run /system/bin/cdm_session_unittest
adb_shell_run /system/bin/file_store_unittest
adb_shell_run /system/bin/license_unittest
adb_shell_run /system/bin/initialization_data_unittest
adb_shell_run /system/bin/device_files_unittest
adb_shell_run /system/bin/timer_unittest

library_path="/system/vendor/lib/mediadrm/ "
adb_shell_run LD_LIBRARY_PATH=$library_path /system/bin/libwvdrmengine_test

adb_shell_run am start com.widevine.test/com.widevine.test.MediaDrmAPITest
if [ $final_result -eq 0 ]; then
  echo "MediaDrm unittests completed successfully!"
else
  printf '\n%s\n' "${failed_tests[@]}"
  exit $final_result
fi

