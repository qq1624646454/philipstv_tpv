/*
 * Copyright (C) 2011 Google, Inc.  All Rights Reserved
 */

#ifndef __WVMLOGGING_H__
#define __WVMLOGGING_H__

void android_printbuf(const char *buf);

#endif
