package com.google.widevine.software.drm;

class StubLib {
}
